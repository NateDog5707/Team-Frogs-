#include "logFile.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

GSTATE *createGameStatement(char *pStatement)
{
  GSTATE *Node;
  Node = malloc(sizeof(GSTATE));
  Node->statement = pStatement;
  Node->logFile = NULL;
  Node->Next = NULL;
  Node->Prev = NULL;
  return Node;
}

LLIST *createLogList(void)
{
  LLIST *l;
  l = malloc(sizeof(LLIST));
  l->Length = 0;
  l->First = NULL;
  l->Last = NULL;
  return l;
}

void appendGameStatement(LLIST *l, GSTATE* Node)
{
  if(l->Length == 0)
  {
    Node->logFile = l;
    l->First = Node;
    l->Last = Node;
    l->Length++;
  }
  else
  {
    Node->logFile = l;
    Node->Prev = l->Last;
    (l->Last)->Next = Node;
    l->Last = Node;
    l->Length++;
  }
}

void printLog(LLIST *l)
{
  GSTATE *temp = l->First;
  for(int i = 0; i < l->Length; i++)
  {
    if(i > 0)
    {
      printf("%d ", i);
    }
    printf("%s\n", temp->statement);
    temp = temp->Next;
  }
}

void printLogToTxt(LLIST *l)
{
  FILE *txtFile;
  txtFile = fopen("exampleLogFile.txt", "w");
  GSTATE *temp = l->First;
  for(int i = 0; i < l->Length; i++)
  {
    fprintf(txtFile, "%s\n", (l->First)->statement);
    l->First = l->First->Next;
  }
  fclose(txtFile);
  l->First = temp;
}
