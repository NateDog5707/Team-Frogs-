#ifndef LOGFILE_H
#define LOGFILE_H
#include <string.h>

typedef struct gameStatement
	 GSTATE;

typedef struct txtLogList
	LLIST;

struct txtLogList{
	int Length;
	GSTATE *First;
	GSTATE *Last;
};

struct gameStatement{//node
	char *statement;
	LLIST *logFile; 
	GSTATE *Next;
	GSTATE *Prev;	
};

GSTATE *createGameStatement(char *pStatement);
LLIST *createLogList(void);
//char[] writePieceStatement();
void appendGameStatement(LLIST *l, GSTATE* Node);
//void undoGameStatement(LLIST *l);
void printLog(LLIST *l);
void printLogToTxt(LLIST *l);
#endif//LOGFILE_H
