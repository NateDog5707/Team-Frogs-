#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include <math.h>

#include "chessPieces.h"


#ifndef BOARD_H
#define BOARD_H


		//32 pieces
		t_chessPiece WhitePawn1N;
		t_chessPiece WhitePawn2N; 
		t_chessPiece WhitePawn3N; 
		t_chessPiece WhitePawn4N;
		t_chessPiece WhitePawn5N; 
		t_chessPiece WhitePawn6N;
		t_chessPiece WhitePawn7N; 
		t_chessPiece WhitePawn8N; 
		t_chessPiece WhiteRook1N; 
		t_chessPiece WhiteRook2N; 
		t_chessPiece WhiteKnight1;
		t_chessPiece WhiteKnight2; 
		t_chessPiece WhiteBishop1; 
		t_chessPiece WhiteBishop2; 
		t_chessPiece WhiteQueen; 
		t_chessPiece WhiteKingN; 
		
		t_chessPiece BlackPawn1N; 
		t_chessPiece BlackPawn2N; 
		t_chessPiece BlackPawn3N; 
		t_chessPiece BlackPawn4N;
		t_chessPiece BlackPawn5N; 
		t_chessPiece BlackPawn6N; 
		t_chessPiece BlackPawn7N; 
		t_chessPiece BlackPawn8N; 
		t_chessPiece BlackRook1N;
		t_chessPiece BlackRook2N;
		t_chessPiece BlackKnight1; 
		t_chessPiece BlackKnight2; 
		t_chessPiece BlackBishop1; 
		t_chessPiece BlackBishop2; 
		t_chessPiece BlackQueen; 
		t_chessPiece BlackKingN; 
	
	
		// 8 pieces for promotion
		t_chessPiece WhiteRookPromotion;
		t_chessPiece WhiteKnightPromotion; 
		t_chessPiece WhiteBishopPromotion; 
		t_chessPiece WhiteQueenPromotion; 
		t_chessPiece BlackRookPromotion;
		t_chessPiece BlackKnightPromotion; 
		t_chessPiece BlackBishopPromotion; 
		t_chessPiece BlackQueenPromotion; 
		
		//pieces to restore
		t_chessPiece WhiteRookR;
		t_chessPiece WhitePawnR;
		t_chessPiece WhiteKnightR;
		t_chessPiece WhiteBishopR;
		t_chessPiece WhiteQueenR;
		t_chessPiece BlackPawnR;
		t_chessPiece BlackRookR;
		t_chessPiece BlackKnightR;
		t_chessPiece BlackBishopR;
		t_chessPiece BlackQueenR;


typedef struct position{
	int rank;
	char file; 
} t_position; // t_pos is the type, not t_position



t_chessPiece **displayBoard(t_chessPiece ** chessboardFirstP, int *isBoardInitialized);

void move(t_chessPiece **chessboardFirstP, t_position *initial, t_position *final);

//void displayBoard(t_chessPiece** chessboard);


#endif
