#include <stdio.h>
#include <string.h>
#include <math.h>

#include "chessPieces.h"
#include "board.h"
#include "moveSet.h"


		//32 pieces
		t_chessPiece WhitePawn1N = { Pawn, White, 0 };
		t_chessPiece WhitePawn2N = { Pawn, White, 0 };
		t_chessPiece WhitePawn3N = { Pawn, White, 0 };
		t_chessPiece WhitePawn4N = { Pawn, White, 0 };
		t_chessPiece WhitePawn5N = { Pawn, White, 0 };
		t_chessPiece WhitePawn6N = { Pawn, White, 0 };	
		t_chessPiece WhitePawn7N = { Pawn, White, 0 };	
		t_chessPiece WhitePawn8N = { Pawn, White, 0 };
		t_chessPiece WhiteRook1N = { Rook, White, 0 };
		t_chessPiece WhiteRook2N = { Rook, White, 0 };
		t_chessPiece WhiteKnight1 = { Knight, White, 1 };
		t_chessPiece WhiteKnight2 = { Knight, White, 1 };
		t_chessPiece WhiteBishop1 = { Bishop, White, 1 };
		t_chessPiece WhiteBishop2 = { Bishop, White, 1 };
		t_chessPiece WhiteQueen = { Queen, White, 1 };	
		t_chessPiece WhiteKingN = { King, White, 0 };
		
		t_chessPiece BlackPawn1N = { Pawn, Black, 0 };
		t_chessPiece BlackPawn2N = { Pawn, Black, 0 };
		t_chessPiece BlackPawn3N = { Pawn, Black, 0 };
		t_chessPiece BlackPawn4N = { Pawn, Black, 0 };
		t_chessPiece BlackPawn5N = { Pawn, Black, 0 };
		t_chessPiece BlackPawn6N = { Pawn, Black, 0 };
		t_chessPiece BlackPawn7N = { Pawn, Black, 0 };
		t_chessPiece BlackPawn8N = { Pawn, Black, 0 };
		t_chessPiece BlackRook1N = { Rook, Black, 0 };
		t_chessPiece BlackRook2N = { Rook, Black, 0 };
		t_chessPiece BlackKnight1 = { Knight, Black, 1 };
		t_chessPiece BlackKnight2 = { Knight, Black, 1 };
		t_chessPiece BlackBishop1 = { Bishop, Black, 1 };
		t_chessPiece BlackBishop2 = { Bishop, Black, 1 };
		t_chessPiece BlackQueen = { Queen, Black, 1 };
		t_chessPiece BlackKingN = { King, Black, 0 };
	
	
		// 8 pieces for promotion
		t_chessPiece WhiteRookPromotion = { Rook, White , 1 };
		t_chessPiece WhiteKnightPromotion = {Knight, White, 1};
		t_chessPiece WhiteBishopPromotion = {Bishop, White, 1};
		t_chessPiece WhiteQueenPromotion = {Queen, White, 1};
		t_chessPiece BlackRookPromotion = {Rook, Black, 1};
		t_chessPiece BlackKnightPromotion = {Knight, Black, 1};
		t_chessPiece BlackBishopPromotion = {Bishop, Black, 1};
		t_chessPiece BlackQueenPromotion = {Queen, Black, 1};

		//pieces to restore
		t_chessPiece WhiteRookR = {Rook, White, 1};
		t_chessPiece WhitePawnR = {Pawn, White, 1};
		t_chessPiece WhiteKnightR = {Knight, White, 1};
		t_chessPiece WhiteBishopR = {Bishop, White, 1};
		t_chessPiece WhiteQueenR = {Queen, White, 1};
		t_chessPiece BlackPawnR = {Pawn, Black, 1};
		t_chessPiece BlackRookR= {Rook, Black, 1};
		t_chessPiece BlackKnightR  = {Knight, Black, 1};
		t_chessPiece BlackBishopR  = {Bishop, Black, 1};
		t_chessPiece BlackQueenR= {Queen, Black, 1};








t_chessPiece **displayBoard(t_chessPiece ** chessboardFirstP, int *isBoardInitialized){

	

		
		/////////////////////////////////////////////////////////
		//4/24/2023
		//initialize 32 pieces for each piece (+ more for moved/haven't moved)
		
			//creating chess pieces, i wonder if there's a better way to do this
		// order of parameters goes pieceName, playerColor, hasMoved
		// names that end in N mean haven't moved [ haven't moved  = 0 ]
		// we only care if a pawn, rook, or king has or hasn't moved 
		
		

 
 
		//!! we have to figure out what to do with the "moved" pawns, rook, and king. like where do we initialize them n what not.
	
		//! the pieces with "N" at the end are initalized to the board. the variant without the 'N' doesn't get initialized, but we need to replace the "N" variant with moved variant when we move them. we should probably create the t_chessPiece for the moved version when inside the move().
	

	

		if(*isBoardInitialized == 0)
	{
		//printf("starting initializing array with null\n");
		//make the array empty initially
		for (int i = 0; i < 8; i++){
			for (int j = 0; j < 8; j++){
				//printf("%d, %d\n", i, j);
				*(chessboardFirstP+j+(i*8)) = (t_chessPiece *)NULL; //make chessboard into null
			}
		}
		//printf("end init array with null\n");
   
		//rank 1
		*(chessboardFirstP+0+(0*8)) = &WhiteRook1N;
		*(chessboardFirstP+1+(0*8)) = &WhiteKnight1;
		*(chessboardFirstP+2+(0*8)) = &WhiteBishop1;
		*(chessboardFirstP+3+(0*8)) = &WhiteQueen;
		*(chessboardFirstP+4+(0*8)) = &WhiteKingN;
		*(chessboardFirstP+5+(0*8)) = &WhiteBishop2;
		*(chessboardFirstP+6+(0*8)) = &WhiteKnight2;
		*(chessboardFirstP+7+(0*8)) = &WhiteRook2N;
		
		//rank 2
		*(chessboardFirstP+0+(1*8)) = &WhitePawn1N;
		*(chessboardFirstP+1+(1*8)) = &WhitePawn2N;
		*(chessboardFirstP+2+(1*8)) = &WhitePawn3N;
		*(chessboardFirstP+3+(1*8)) = &WhitePawn4N;
		*(chessboardFirstP+4+(1*8)) = &WhitePawn5N;
		*(chessboardFirstP+5+(1*8)) = &WhitePawn6N;
		*(chessboardFirstP+6+(1*8)) = &WhitePawn7N;
		*(chessboardFirstP+7+(1*8)) = &WhitePawn8N;
		
		
		
		//rank 7
		*(chessboardFirstP+0+(6*8)) = &BlackPawn1N;
		*(chessboardFirstP+1+(6*8)) = &BlackPawn2N;
		*(chessboardFirstP+2+(6*8)) = &BlackPawn3N;
		*(chessboardFirstP+3+(6*8)) = &BlackPawn4N;
		*(chessboardFirstP+4+(6*8)) = &BlackPawn5N;
		*(chessboardFirstP+5+(6*8)) = &BlackPawn6N;
		*(chessboardFirstP+6+(6*8)) = &BlackPawn7N;
		*(chessboardFirstP+7+(6*8)) = &BlackPawn8N;
		
		//rank 8
		*(chessboardFirstP+0+(7*8)) = &BlackRook1N;
		*(chessboardFirstP+1+(7*8)) = &BlackKnight1;
		*(chessboardFirstP+2+(7*8)) = &BlackBishop1;
		*(chessboardFirstP+3+(7*8)) = &BlackQueen;
		*(chessboardFirstP+4+(7*8)) = &BlackKingN;
		*(chessboardFirstP+5+(7*8)) = &BlackBishop2;
		*(chessboardFirstP+6+(7*8)) = &BlackKnight2;
		*(chessboardFirstP+7+(7*8)) = &BlackRook2N;
		
	}
	
	
/*
	//debug FOR ADDRESSES OF INDEXES ----------------------------- inside displayBoard()
 
	t_chessPiece *currPiece;
	for (int i = 7; i >= 0; i--){
		for (int j = 0; j < 8; j++){
			currPiece = *(chessboardFirstP+j+(i*8));
			if (currPiece != NULL){
				printf("Index [%d][%d] has an address of %d\n", i, j, &(*(chessboardFirstP+j+(i*8))));
			}
			else{
				printf("Index [%d][%d] is empty\n", i, j);
			}
		}
	}	
	*/

  //printf("IN DISPLAY BOARD, board.c\n");
	int count = 7; //basically rank
	printf("\n");
	while (count >= 0){
		printf("    +----+----+----+----+----+----+----+----+\n");
		printf("  %d |", count+1); //prints row number);
		
		for( int i = 0; i < 8; i++){ //i is basically file, x axis
		
			if (*(chessboardFirstP+ i + (count*8)) == (t_chessPiece *) NULL){ //changed to reference to a pointer
				printf("    |");
				
			}
			else if ((**(chessboardFirstP + i + (count * 8))).color == White){//changed to dereference double pointer
			
				switch((**(chessboardFirstP + i + (count * 8))).pieceType){ //enum pieceType is the switch
					case 0: //might have to change case to the numbers---------------------------------------------------------------
						printf(" wP |");
						break;
					case 1:
						printf(" wR |");
						break;
					case 2:
						printf(" wN |");
						break;
					case Bishop:
						printf(" wB |");
						break;
					case Queen:
						printf(" wQ |");
						break;
					case King:
						printf(" wK |");
						break;
					default:
						printf(" w? |"); //if null pointer, blank space
						break;
				} //switch end
					
			} //else if end . white
			
			else if ((**(chessboardFirstP + i + (count * 8))).color == Black){//changed to dereference double pointer
				switch((**(chessboardFirstP + i + (count * 8))).pieceType){
					case Pawn:
						printf(" bP |");
						break;
					case Rook:
						printf(" bR |");
						break;
					case Knight:
						printf(" bN |");
						break;
					case Bishop:
						printf(" bB |");
						break;
					case Queen:
						printf(" bQ |");
						break;
					case King:
						printf(" bK |");
						break;
					default:
						printf(" b? |"); //if null pointer, blank space
						break;
				}//switch end
			}//else if end . black
	
	
			else { //for debugging, we dont want it to hit an else
				printf("ERRO|");
			
			}
			
				
		}//for i end, go to the next row
		printf("\n    +----+----+----+----+----+----+----+----+\n");
		//below chessboard, print files
		count--;
	
	}// while end
	printf("      a    b    c    d    e    f    g    h \n");




	//debug at the end of displayboard
	//printf("%d\n%d\n", &chessboardFirstP, &chessboardFirstPSave);
	//chessboardFirstP = chessboardFirstPSave;
	//printf("%d\n%d\n", &chessboardFirstP, &chessboardFirstPSave);


	return chessboardFirstP; //return pointer to the first index
}/*displayBoard() end*/







void move(t_chessPiece** const chessboardFirstP, t_position *initial, t_position *final){
	
	int convertedFileInit, convertedRankInit;
	int convertedFileFin, convertedRankFin;
	
	
	convertedRankInit = (*initial).rank - 1;
	convertedRankFin = (*final).rank - 1;
	

	
	switch (initial->file){
		case 'a':
			convertedFileInit = 0;
			break;
		case 'b':
			convertedFileInit = 1;
			break;
		case 'c':
			convertedFileInit = 2;
			break;
		case 'd':
			convertedFileInit = 3;
			break;
		case 'e':
			convertedFileInit = 4;
			break;
		case 'f':
			convertedFileInit = 5;
			break;
		case 'g':
			convertedFileInit = 6;
			break;
		case 'h':
			convertedFileInit = 7;
			break;
		default:
			convertedFileInit = 0;
			break;
	
	}//switch initial->file end
	
	
	switch (final->file){
		case 'a':
			convertedFileFin = 0;
			break;
		case 'b':
			convertedFileFin = 1;
			break;
		case 'c':
			convertedFileFin = 2;
			break;
		case 'd':
			convertedFileFin = 3;
			break;
		case 'e':
			convertedFileFin = 4;
			break;
		case 'f':
			convertedFileFin = 5;
			break;
		case 'g':
			convertedFileFin = 6;
			break;
		case 'h':
			convertedFileFin = 7;
			break;
		default:
			convertedFileFin = 0;
			break;
	
	}//switch final->file end

	//printf("initial rank is %d, converted init rank is %d\n", (*initial).rank, convertedRankInit);
	//printf("final rank is %d, converted final rank is %d\n", (*final).rank, convertedRankFin);
	
	//printf("initial file is %c, converted init file is %d\n", (*initial).file, convertedFileInit);
	//printf("final file is %c, converted final file is %d\n", (*final).file, convertedFileFin);
 

	
	
	//debug
	//printf("help\n");
	
	
	//PROMOTION, CASTLING, EN PASSANT
	t_chessPiece* piece = *(chessboardFirstP + convertedFileInit + (convertedRankInit * 8));
	int promotion_choice;
	
	//moving piece from initial position to final position
	//*(chessboardFirstP+convertedFileFin+(convertedRankFin*8))  =  *(chessboardFirstP + convertedFileInit+(convertedRankInit * 8));
	
	//PROMOTION
	if(piece -> pieceType == Pawn)
	{
		if((piece -> color == White) && (convertedRankFin == 7))
		{
			printf("-------- Promotion! --------\n");
			printf("\t1. Rook\n");
			printf("\t2. Knight\n");
			printf("\t3. Bishop\n");
			printf("\t4. Queen\n");
			printf("Choose a piece: ");
			scanf("%d", &promotion_choice); 
			
			
			switch(promotion_choice){
				case 1:
					//White Rook
					*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = &WhiteRookPromotion;
					break;
				case 2:
					//White Knight
					*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = &WhiteKnightPromotion;
					break;
				case 3:
					//White Bishop
					*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = &WhiteBishopPromotion;
					break;
				case 4:
					//White Queen
					*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = &WhiteQueenPromotion;
					break;
				default:
					//default = White Queen
					*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = &WhiteQueenPromotion;
					break;
			}
			
		}
		else if((piece -> color == Black) && (convertedRankFin == 0))
		{
			printf("Promotion! Choose a piece: ");
			printf("1. Rook\n");
			printf("2. Knight\n");
			printf("3. Bishop\n");
			printf("4. Queen\n");
			scanf("%d", &promotion_choice); 
			
			switch(promotion_choice){
				case 1:
					//Black Rook
					*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = &BlackRookPromotion;
					break;
				case 2:
					//Black Knight
					*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = &BlackKnightPromotion;
					break;
				case 3:
					//Black Bishop
					*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = &BlackBishopPromotion;
					break;
				case 4:
					//Black Queen
					*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = &BlackQueenPromotion;
					break;
				default:
					//default = Black Queen
					*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = &BlackQueenPromotion;
					break;
			}
			
		}
		//EN PASSANT
		//en passant to top right
		else if((piece -> color == White) && (initial -> rank == 5) && (final -> rank == 6) && (convertedFileFin == convertedFileInit + 1) && (*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) == NULL))
		{
			//capture enemy pawn using en passant
			*(chessboardFirstP+(convertedFileInit+1)+(convertedRankInit*8)) = (t_chessPiece *)NULL;
				
			//move pawn normally
			*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = piece;

		}
		//en passant to top left
		else if((piece -> color == White) && (initial -> rank == 5) && (final -> rank == 6) && (convertedFileFin == convertedFileInit - 1) && (*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) == NULL))
		{
			//capture enemy pawn using en passant
			*(chessboardFirstP+(convertedFileInit-1)+(convertedRankInit*8)) = (t_chessPiece *)NULL;
				
			//move pawn normally
			*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = piece;
		}
		//en passant to bottom right
		else if((piece -> color == Black) && (initial -> rank == 4) && (final -> rank == 3) && (convertedFileFin == convertedFileInit + 1) && (*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) == NULL))
		{
			//capture enemy pawn using en passant
			*(chessboardFirstP+(convertedFileInit+1)+(convertedRankInit*8)) = (t_chessPiece *)NULL;
				
			//move pawn normally
			*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = piece;

		}
		//en passant to bottom left
		else if((piece -> color == Black) && (initial -> rank == 4) && (final -> rank == 3) && (convertedFileFin == convertedFileInit - 1) && (*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) == NULL))
		{ 
			//capture enemy pawn using en passant
			*(chessboardFirstP+(convertedFileInit-1)+(convertedRankInit*8)) = (t_chessPiece *)NULL;
				
			//move pawn normally
			*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = piece;

		}
		else
		{
			*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = piece;
		}
	}
	//CASTLING
	else if(piece -> pieceType == King)
	{
		if(piece -> hasMoved == 0)
		{
			//printf("king hasn't moved\n");
			//WHITE SIDE CASTLING
			if(piece -> color == White)
			{
				//printf("white king\n");
				//printf("convertedFileFin: %d, convertedRankFin: %d, convertedFileInit: %d, convertedRankInit: %d\n", convertedFileFin, convertedRankFin, convertedFileInit, convertedRankInit);
				//WHITE KING SIDE CASTLING
				if((convertedRankFin == convertedRankInit) && (convertedFileFin == (convertedFileInit + 2)))
				{
					//printf("correct castling positions\n");
					if((WhiteRook2N.hasMoved == 0) && 
						(*(chessboardFirstP+5+(0*8)) == NULL) && (*(chessboardFirstP+6+(0*8)) == NULL))
					{
						//printf("no pieces between\n");
						//remove rook from original position
						*(chessboardFirstP+7+(0*8)) = (t_chessPiece *)NULL;
						
						//move rook to new position
						*(chessboardFirstP+5+(0*8)) = &WhiteRook2N;
						
					}
				}
				//WHITE QUEEN SIDE CASTLING
				else if((convertedRankFin == convertedRankInit) && (convertedFileFin == (convertedFileInit - 2)))   
				{
					if((WhiteRook1N.hasMoved == 0) && 
						(*(chessboardFirstP+3+(0*8)) == NULL) && (*(chessboardFirstP+2+(0*8)) == NULL) && (*(chessboardFirstP+1+(0*8)) == NULL))
					{
						//remove rook from original position
						*(chessboardFirstP+0+(0*8)) = (t_chessPiece *)NULL;
						
						//move rook to new position
						*(chessboardFirstP+3+(0*8)) = &WhiteRook1N;
						
					}
				
				}
			}
			//BLACK SIDE CASTLING
			else if(piece -> color == Black)
			{
				//BLACK KING SIDE CASTLING
				if((convertedRankFin == convertedRankInit) && (convertedFileFin == (convertedFileInit + 2)))
				{
					if((BlackRook2N.hasMoved == 0) && 
						(*(chessboardFirstP+5+(7*8)) == NULL) && (*(chessboardFirstP+6+(7*8)) == NULL))
					{
						//remove rook from original position
						*(chessboardFirstP+7+(7*8)) = (t_chessPiece *)NULL;
						
						//move rook to new position
						*(chessboardFirstP+5+(7*8)) = &BlackRook2N;
						
					}
				}
				//BLACK QUEEN SIDE CASTLING
				else if((convertedRankFin == convertedRankInit) && (convertedFileFin == (convertedFileInit - 2)))   
				{
					if((BlackRook1N.hasMoved == 0) && 
						(*(chessboardFirstP+3+(7*8)) == NULL) && (*(chessboardFirstP+2+(7*8)) == NULL) && (*(chessboardFirstP+1+(7*8)) == NULL))
					{
						//remove rook from original position
						*(chessboardFirstP+0+(7*8)) = (t_chessPiece *)NULL;
						
						//move rook to new position
						*(chessboardFirstP+3+(7*8)) = &BlackRook1N;
						
					}
				}
			}
		}

		//moves king to the correct final position regardless of castling
		*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = piece;

	}
	//REGULAR MOVE
	else
	{
		*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) = piece;
	}
	
	
	//hasMoved from 0 => 1
	
	if ((**(chessboardFirstP + convertedFileInit + (convertedRankInit *8))).hasMoved == 0){
		(**(chessboardFirstP + convertedFileInit + (convertedRankInit *8))).hasMoved = 1;
	}
	
	//moved hasMoved check to here so that move() can check castling etc.	
	
	//debug
	//if ((**(chessboardFirstP+convertedFileFin+(convertedRankFin*8))).pieceType){
	//	printf("something is in the new position!\n");
	//}
	
			//debug
	//printf("%d @ end of move()\n", &chessboardFirstP);
	
	//assigning null to initial position
	*(chessboardFirstP+convertedFileInit+(convertedRankInit*8)) = (t_chessPiece *)NULL;
	
		//if (*(chessboardFirstP+convertedFileFin+(convertedRankFin*8)) == (t_chessPiece *)NULL ){
		//	printf("nothing is in the old position!\n");
		//}


} //move() end














