  //#include "protoCheckStatus.h"
#include "checkStatus.h"
#include "computerMoves.h"
#include "chessPieces.h"
#include "board.h"



t_position findEnemyKing(int oppColor, t_chessPiece** chessBoard) { 
  t_position kingPos;
  
  for(int i = 0; i < 8; i++)
    {
      for(int j = 0; j < 8; j++)
        {
        	//printf("%d, %d\n", i, j);
        	if (*(chessBoard+j +(i*8)) != NULL){
        	//IMPORTANT LINE--- we shouldn't access .pieceType if there is a null pointer b/c it leads to segfault. Check FIRST if the pointer is NOT NULL, then access the stuff  	
          	 if((**(chessBoard + j + (i * 8))).pieceType == King && (**(chessBoard + j + (i * 8))).color == oppColor)
          	 //if(chessBoard[i][j]->pieceType == King && chessBoard[i][j]->color == oppColor) //finding enemy king?
           	 {
          	  	// King's Rank and File
           	 		kingPos.rank = i + 1;
          	  	kingPos.file = intToChar(j);
//printf("IN FIND ENEMY KING: %d's king is at %c%d\n", oppColor, kingPos.file, kingPos.rank);

          	 }
        	}
	      }
     }// End of Search for King  
  return kingPos;
}

int charToInt(char file) {
  int conFile;
  switch (file) {
    case 'a': conFile = 0;
    	break;
    case 'b': conFile = 1;
    	break;
    case 'c': conFile = 2;
    	break;
    case 'd': conFile = 3;
    	break;
    case 'e': conFile = 4;
    	break;
    case 'f': conFile = 5;
    	break;
    case 'g': conFile = 6;
    	break;
    case 'h': conFile = 7;
    	break;
  }
  return conFile;
}

char intToChar(int file) {
  char conFile;
  switch (file) {
    case 0: conFile = 'a';
    	break;
    case 1: conFile = 'b';
    	break;
    case 2: conFile = 'c';
    	break;
    case 3: conFile = 'd';
    	break;
    case 4: conFile = 'e';
    	break;
    case 5: conFile = 'f';
    	break;
    case 6: conFile = 'g';
    	break;
    case 7: conFile = 'h';
    	break;
  }
  return conFile;
}

int inCheck(int moverColor, int oppColor, t_chessPiece** chessBoard, t_logList *moveLog) //moverColor is the color of the current player's turn
{//White = 1, Black = 0

  int check = 0; 
  
//------------SEARCH FOR KING------------
  

  t_position kingPos = findEnemyKing(oppColor, chessBoard);
//printf("found enemy king bb\n");
	int kRank = kingPos.rank - 1;
  int kFile = charToInt(kingPos.file);



//------------SEARCH FOR PIECE IN CARDINAL DIRECTIONS-------
  t_position temp;
  MOVESET* threatPieceMoveList = malloc(32 * sizeof(MOVESET));
//printf("north\n");
//north
  for(int up = kRank + 1; up < 8; up++)
    { //could implement a repeat to break out of main loop
   	if (*(chessBoard+ kFile +(up*8)) != NULL){
      if((**(chessBoard + kFile + (up * 8))).color == oppColor)
      //if(chessBoard[up][kFile]->color == moverColor) //if closest piece is ally, break 
      	{
      	  break; //out of for loop north
      	}
      else if((**(chessBoard + kFile + (up * 8))).color == moverColor && (**(chessBoard + kFile + (up * 8))).pieceType != Bishop && (**(chessBoard + kFile + (up * 8))).pieceType != Pawn) 
      	{ //for loop to iterate through chessBoard and find if oppColor 
          temp.rank = up + 1;
          temp.file = intToChar(kFile);
      	  threatPieceMoveList = allLegalMoves(chessBoard, &temp, moveLog); //from moveSet.h, grabs all legal moves of the enemy piece
          break;
      	}
     	}
    } // End of check for opponent piece North of king
     for(int i = 0; i < 32; i++) 
          {
            if((kingPos.rank - 1) == threatPieceMoveList[i].final_rank && charToInt(kingPos.file) == threatPieceMoveList[i].final_file) //if king's pos is within the enemy piece's allLegalMoves list
              {
                check++;
                break;
              }
          }
//printf("west\n");
//west
  for(int left = kFile - 1; left >= 0; left--)
    {
    if (*(chessBoard+ left +(kRank*8)) != NULL){
  		//printf("%d\n", left);
      if((**(chessBoard + left + (kRank * 8))).color == oppColor)
        {
	        break;
	      }
      else if((**(chessBoard + left + (kRank * 8))).color == moverColor && (**(chessBoard + left + (kRank * 8))).pieceType != Bishop && (**(chessBoard + left + (kRank * 8))).pieceType != Pawn)
      	{
          temp.rank = kRank + 1;
          temp.file = intToChar(left);
      	  threatPieceMoveList = allLegalMoves(chessBoard, &temp, moveLog); //from moveSet.h 
          break;
      	}
   		}
  } //End of check for opponent piece West of king
  for(int i = 0; i < 32; i++) 
          {
            if((kingPos.rank - 1) == threatPieceMoveList[i].final_rank && charToInt(kingPos.file) == threatPieceMoveList[i].final_file) //if king's pos is within the enemy piece's allLegalMoves list
              {
                check++;
                break;
              }
          }
          
//printf("south\n");

//south
  for(int down = kRank - 1; down >= 0; down--)
    {
    if (*(chessBoard+ kFile +(down*8)) != NULL){
    	//printf("%d\n", down);
      if((**(chessBoard + kFile + (down * 8))).color == oppColor)
      {
	      break;
      }
      else if((**(chessBoard + kFile + (down * 8))).color == moverColor && (**(chessBoard + kFile + (down * 8))).pieceType != Bishop && (**(chessBoard + kFile + (down * 8))).pieceType != Pawn)
      {
          temp.rank = down + 1;
          temp.file = intToChar(kFile);
      	  threatPieceMoveList = allLegalMoves(chessBoard, &temp, moveLog); //from moveSet.h 
          break;
      }
    } 
	} //End of check for opponent piece South of king
 for(int i = 0; i < 32; i++) 
          {
            if((kingPos.rank - 1) == threatPieceMoveList[i].final_rank && charToInt(kingPos.file) == threatPieceMoveList[i].final_file) //if king's pos is within the enemy piece's allLegalMoves list
              {
                check++;
                break;
              }
          }
 
//printf("east\n");
//east
  for(int right = kFile + 1; right < 8; right ++)
    {
    if (*(chessBoard+ right +(kRank*8)) != NULL){
    	if((**(chessBoard + right + (kRank * 8))).color == oppColor)
    	  {
    	    break;
    	  }
    	else if((**(chessBoard + right + (kRank * 8))).color == moverColor && (**(chessBoard + right + (kRank * 8))).pieceType != Bishop && (**(chessBoard + right + (kRank * 8))).pieceType != Pawn)
    	  {
              temp.rank = kRank + 1;
              temp.file = intToChar(right);
          	  threatPieceMoveList = allLegalMoves(chessBoard, &temp, moveLog); //from moveSet.h 
              break;
    	  }
    } 
	}//End of check for opponent piece East of king
       for(int i = 0; i < 32; i++) 
              {
                if((kingPos.rank - 1) == threatPieceMoveList[i].final_rank && charToInt(kingPos.file) == threatPieceMoveList[i].final_file) //if king's pos is within the enemy piece's allLegalMoves list
                  {
                    check++;
                    break;
                  }
              }

//printf("upperRight\n");
//--------------SEARCH DIAGONALS-------------
//upperRight diagonal

    int diaTempFile = kFile + 1;
    int diaTempRank = kRank + 1;

  while(diaTempFile < 8 && diaTempRank < 8)
    {
    //printf("%d %d\n", diaTempRank, diaTempFile);
    if (*(chessBoard+ diaTempFile +(diaTempRank*8)) != NULL){
      if((**(chessBoard + diaTempFile + (diaTempRank * 8))).color == oppColor)
        {
  	      break;
        }
//      else if((**(chessBoard + diaTempFile + (diaTempRank * 8))).color == moverColor && ((**(chessBoard + diaTempFile + (diaTempRank * 8))).pieceType == Bishop ||
//       (**(chessBoard + diaTempFile + (diaTempRank * 8))).pieceType == Pawn || (**(chessBoard + diaTempFile + (diaTempRank * 8))).pieceType == Queen)) //bishop, pawn, queen can move diagonal
        else if ((**(chessBoard + diaTempFile + (diaTempRank * 8))).color == moverColor)
				{
          temp.rank = diaTempRank + 1;
          temp.file = intToChar(diaTempFile);
      	  threatPieceMoveList = allLegalMoves(chessBoard, &temp, moveLog); //from moveSet.h 
          break;
        }
//      diaTempRank++;
//    	diaTempFile++;
     }
      diaTempRank++;
    	diaTempFile++;
  	}// while end
  	 for(int i = 0; i < 32; i++) 
          {
            if((kingPos.rank - 1) == threatPieceMoveList[i].final_rank && charToInt(kingPos.file) == threatPieceMoveList[i].final_file) //if king's pos is within the enemy piece's allLegalMoves list
              {
                check++;
                break;
              }
          }
//printf("upperLeft\n");
  //upperLeft diagonal
  diaTempFile = kFile - 1;
  diaTempRank = kRank + 1;
  
  while(diaTempFile >= 0 && diaTempRank < 8)
    {
//printf("%d %d\n", diaTempFile, diaTempRank);
    if (*(chessBoard+ diaTempFile +(diaTempRank*8)) != NULL){
//printf("i'm in love with the shape of you\n");
      if((**(chessBoard + diaTempFile + (diaTempRank * 8))).color == oppColor)
        {
//printf("we push and pull like a magnet do\n");
          break;
        }
//      else if((**(chessBoard + diaTempFile + (diaTempRank * 8))).color == moverColor && ((**(chessBoard + diaTempRank + (diaTempFile * 8))).pieceType == Bishop ||
//       (**(chessBoard + diaTempFile + (diaTempRank * 8))).pieceType == Pawn || (**(chessBoard + diaTempFile + (diaTempRank * 8))).pieceType == Queen))
				else if ((**(chessBoard +diaTempFile + (diaTempRank*8))).color == moverColor)
	      {
        
//printf("although my heart is falling too\n");
          temp.rank = diaTempRank + 1;
          temp.file = intToChar(diaTempFile);
      	  threatPieceMoveList = allLegalMoves(chessBoard, &temp, moveLog); //from moveSet.h 
          break;
//printf("i'm in love with you're body\n");
        }
//      diaTempRank--;
//      diaTempFile++;
      }
//printf("last night you were in my room\n");
      diaTempRank--;
      diaTempFile++; 
    } //while end
  for(int i = 0; i < 32; i++) 
          {
            if((kingPos.rank - 1) == threatPieceMoveList[i].final_rank && charToInt(kingPos.file) == threatPieceMoveList[i].final_file) //if king's pos is within the enemy piece's allLegalMoves list
              {
                check++;
                break;
              }
            }
//printf("lowerLeft\n");
  //lowerLeft diagonal
  diaTempFile = kFile -1;
  diaTempRank = kRank -1;

  while(diaTempFile >= 0 && diaTempRank >= 0)
    {
//printf("%d %d\n", diaTempFile, diaTempRank);
    if (*(chessBoard+ diaTempFile +(diaTempRank*8)) != NULL){
      if((**(chessBoard + diaTempFile + (diaTempRank * 8))).color == oppColor)
        {
          break;
        }
//      else if((**(chessBoard + diaTempFile + (diaTempRank * 8))).color == moverColor && ((**(chessBoard + diaTempFile + (diaTempRank * 8))).pieceType == Bishop ||
//       (**(chessBoard + diaTempFile + (diaTempRank * 8))).pieceType == Pawn || (**(chessBoard + diaTempFile + (diaTempRank * 8))).pieceType == Queen))
 				else if ((**(chessBoard + diaTempFile + (diaTempRank * 8))).color == moverColor)
        {
          temp.rank = diaTempRank + 1;
          temp.file = intToChar(diaTempFile);
      	  threatPieceMoveList = allLegalMoves(chessBoard, &temp, moveLog); //from moveSet.h 
          break;
        }
//      diaTempRank--;
//      diaTempFile--;
      }
      diaTempRank--;
      diaTempFile--;
    }  
   for(int i = 0; i < 32; i++) 
          {
            if((kingPos.rank - 1) == threatPieceMoveList[i].final_rank && charToInt(kingPos.file) == threatPieceMoveList[i].final_file) //if king's pos is within the enemy piece's allLegalMoves list
              {
                check++;
                break;
              }
          }
          
//printf("lowerRight\n");          
  //lowerright diagonal
  diaTempFile = kFile + 1; 
  diaTempRank = kRank - 1; 
  while(diaTempFile < 8 && diaTempRank >= 0)
    {
    if (*(chessBoard+ diaTempFile +(diaTempRank*8)) != NULL){
      if((**(chessBoard + diaTempFile + (diaTempRank * 8))).color == oppColor)
        {
            break;
        }
//      else if((**(chessBoard + diaTempFile + (diaTempRank * 8))).color == moverColor && ((**(chessBoard + diaTempFile + (diaTempRank * 8))).pieceType == Bishop ||
//       (**(chessBoard + diaTempFile + (diaTempRank * 8))).pieceType == Pawn || (**(chessBoard + diaTempFile + (diaTempRank * 8))).pieceType == Queen))
    		else if ((**(chessBoard + diaTempFile + (diaTempRank * 8))).color == moverColor)
		    {
          temp.rank = diaTempRank + 1;
          temp.file = intToChar(diaTempFile);
       //   printf("Rank: %d, File: %c", temp.rank, temp.file);
      	  threatPieceMoveList = allLegalMoves(chessBoard, &temp, moveLog); //from moveSet.h 
          break;
        }
      }
      diaTempRank++;
      diaTempFile--;
    }//while end
for(int i = 0; i < 32; i++) 
          {
            if((kingPos.rank - 1) == threatPieceMoveList[i].final_rank && charToInt(kingPos.file) == threatPieceMoveList[i].final_file) //if king's pos is within the enemy piece's allLegalMoves list
              {
                check++;
                break;
              }
          }

//printf("Knights\n");
	//check knights
	
	//search for the ally knights to see if they can attack the king
	for (int i = 0; i < 8; i++){
		for (int j = 0; j < 8; j++){
	
			
			if (*(chessBoard+ j +(i*8)) != NULL){
			
				if ( (**(chessBoard +j +(i*8))).pieceType == Knight && (**(chessBoard+j + (i*8))).color == moverColor){
			
					temp.rank = i + 1;
					temp.file = intToChar(j);
					threatPieceMoveList = allLegalMoves(chessBoard, &temp, moveLog);		//seegfalt
					break;
		
				}// if end
	
			}
		}
	} // for end
for (int k = 0; k < 32; k++){
						if ((kingPos.rank - 1) == threatPieceMoveList[k].final_rank && charToInt(kingPos.file) == threatPieceMoveList[k].final_file)
						{
							check++;
							break;
						}	
					}//for 

//printf("EOF inCheck\n");
//printf("CHECK: %d\n", check);
  return check;
}//END OF inCheck





int inCheckmate(int oppColor, t_chessPiece **chessboard, t_logList *moveLog)
{
  /*
    1. inCheck is true
    2. make an array of size 8 of type t_position and initialize each index to hold rank = 0 and file = 'N'
    3. if the pieces around the king are the same color, record those positions in the surroundingKing array
    4. check allLegalMoves for each enemy piece. if one of the moves for that piece can attack one of the eight
    surrounding squares, save that move to an array
    5. do the same for each player piece including the king and save the moves to another array.
    6. compare the two arrays. if an enemy piece and player piece have the same move, move that position to the surroundingKing
    array
    7. if in one or more index of the array, rank = -1 and file = N, the king is in checkmate
  */
  
  t_position kingPos = findEnemyKing(oppColor, chessboard);
  t_position *surroundingKing = malloc(8 * sizeof(t_position));
  t_position *moveKing = malloc(8 * sizeof(t_position));
  for(int i = 0; i < 8; i++)
  {
    moveKing[i].rank = -1;
    moveKing[i].file = 'N';
    surroundingKing[i].rank = -1;
    surroundingKing[i].file = 'N';
  }
  
  int counter = 0;
  int mCounter = 0;
  int row1 = kingPos.rank +1 - 1;//rank
  int row2 = kingPos.rank - 1;
  int row3 = kingPos.rank - 1 - 1;
  int start = charToInt(kingPos.file) - 1;
  int end = charToInt(kingPos.file) + 1;
  if(start < 0)
  {
    start++;
  }
  if(end > 7)
  {
    end--;
  }
  
  for(int i = start; i <= end; i++)//file
  {
    //row1
    if(row1 < 8)
    {
      if((*(chessboard + i + (row1 * 8))) != NULL)
      {
        if((**(chessboard + i + (row1 * 8))).color == oppColor)
        {
          surroundingKing[counter].rank = row1 + 1;
          surroundingKing[counter].file = intToChar(i);
          counter++;
        }
        if((**(chessboard + i + (row1 * 8))).color != oppColor)
        {
          moveKing[mCounter].rank = row1 + 1;
        moveKing[mCounter].file = intToChar(i);
        mCounter++;
        }
      }
      if((*(chessboard + i + (row1 * 8))) == NULL)
      {
        moveKing[mCounter].rank = row1 + 1;
        moveKing[mCounter].file = intToChar(i);
        mCounter++;
      }
    }
    else if(row1 == 8)
    {
      surroundingKing[counter].rank = 10;
      counter++;
    }
    
    
    //row2
    if((*(chessboard + i + (row2 * 8))) != NULL && i != start + 1)
    {
      if((**(chessboard + i + (row2 * 8))).color == oppColor)
      {
        surroundingKing[counter].rank = row2 + 1;
        surroundingKing[counter].file = intToChar(i);
        counter++;
      }
      if((**(chessboard + i + (row2 * 8))).color != oppColor)
      {
        moveKing[mCounter].rank = row2 + 1;
        moveKing[mCounter].file = intToChar(i);
        mCounter++;
      }
    }
    if((*(chessboard + i + (row2 * 8))) == NULL)
    {
        moveKing[mCounter].rank = row2 + 1;
        moveKing[mCounter].file = intToChar(i);
        mCounter++;
    }
    
    
    //row3
    if(row3 >= 0)
    {
    if((*(chessboard + i + (row3 * 8))) != NULL)
    {
      if((**(chessboard + i + (row3 * 8))).color == oppColor)
      {
        surroundingKing[counter].rank = row3 + 1;
        surroundingKing[counter].file = intToChar(i);
        counter++;
      }
      if((**(chessboard + i + (row3 * 8))).color != oppColor)
      {
        moveKing[mCounter].rank = row3 + 1;
        moveKing[mCounter].file = intToChar(i);
        mCounter++;
      }
    }
       if((*(chessboard + i + (row3 * 8))) == NULL)
      {
        moveKing[mCounter].rank = row3 + 1;
        moveKing[mCounter].file = intToChar(i);
        mCounter++;
      }
   }
   else if(row3 < 0)
    {
      surroundingKing[counter].rank = 10;
      counter++;
    }
  }//end of for loop
  
/*  
  //Where can the king move after this?, positions are stored in moveKing.
//    printf("\nWhere can the king move?\n");
    for(int i = 0; i < 8; i++)
    {
//   printf("\nRank: %d File %c\n",moveKing[i].rank, moveKing[i].file);
    }
  */
  
  
  
  t_position pos;
  
  //for enemy moves
  int counter2 = 0;
  t_position *enemyMoves = malloc(8 * sizeof(t_position));
  for(int i = 0; i < 8; i++){
    for(int j = 0; j < 8; j++){
      if((*(chessboard + j + (i * 8))) != NULL)
      {
        MOVESET *move = malloc(32 * sizeof(MOVESET));
        if((**(chessboard + j + (i * 8))).color == oppColor && (**(chessboard + j + (i * 8))).pieceType != King)
        {
          pos.rank = i + 1;
          pos.file = intToChar(j);
          move = allLegalMoves(chessboard, &pos, moveLog);
          for(int k = 0; k <32; k++)
          {
            //column 1
            if(move[k].final_file == start)
            {
              if(move[k].final_rank == row1 || move[k].final_rank == row2 || move[k].final_rank == row3)
              {
                enemyMoves[counter2].rank = move[k].final_rank + 1;
                enemyMoves[counter2].file = intToChar(move[k].final_file);
                counter2++;
              }
            }
            //column 2
            if( move[k].final_file == start + 1)
            {
               if(move[k].final_rank == row1 || move[k].final_rank == row2 || move[k].final_rank == row3)
              {
                enemyMoves[counter2].rank = move[k].final_rank + 1;
                enemyMoves[counter2].file = intToChar(move[k].final_file);
                counter2++;
              }
            }
            //column 3
            if(move[k].final_file == end)
            {
               if(move[k].final_rank == row1 || move[k].final_rank == row2 || move[k].final_rank == row3)
              {
                enemyMoves[counter2].rank = move[k].final_rank + 1;
                enemyMoves[counter2].file = intToChar(move[k].final_file);
                counter2++;
              }
            }
          }
          
        }
      }
    }
  }//end of for loop
  //for player moves
   int counter3 = 0;
  t_position *playerMoves = malloc(8 * sizeof(t_position));
  for(int i = 0; i < 8; i++){
    for(int j = 0; j < 8; j++){
      if((*(chessboard + j + (i * 8))) != NULL)
      {
        MOVESET *move = malloc(32 * sizeof(MOVESET));
        if((**(chessboard + j + (i * 8))).color != oppColor)
        {
          pos.rank = i + 1;
          pos.file = intToChar(j);
          move = allLegalMoves(chessboard, &pos, moveLog);          
          for(int k = 0; k <32; k++)
          {
            //column 1
            if((move[k].final_rank == row1 || move[k].final_rank == row2 || move[k].final_rank == row3)  && move[k].final_file == start)
            {
              playerMoves[counter3].rank = move[k].final_rank + 1;
              playerMoves[counter3].file = intToChar(move[k].final_file);
              counter3++;
            }
            //column 2
            if((move[k].final_rank == row1 || move[k].final_rank == row2 || move[k].final_rank == row3)  && move[k].final_file == start + 1)
            {
              playerMoves[counter3].rank = move[k].final_rank + 1;
              playerMoves[counter3].file = intToChar(move[k].final_file);
              counter3++;
            }
            //column 3
            if((move[k].final_rank == row1 || move[k].final_rank == row2 || move[k].final_rank == row3)  && move[k].final_file == end)
            {
              playerMoves[counter3].rank = move[k].final_rank + 1;
              playerMoves[counter3].file = intToChar(move[k].final_file);
              counter3++;
            }
          }
          
        }
      }
      if(counter3 > 8)
        break;
    }
  }//end of for loop
  
  int moverColor;
  if(oppColor == 0){
    moverColor = 1;
    }
  else
  {
    moverColor = 0;
  }
  
  for(int i = 0; i < 8; i++){
    for(int j = 0; j < 8; j++){
       if(playerMoves[i].rank == enemyMoves[j].rank && playerMoves[i].file == enemyMoves[j].file && playerMoves[i].rank != 0 && enemyMoves[j].rank != 0)
       {
         surroundingKing[counter].rank = playerMoves[i].rank;
         surroundingKing[counter].file = enemyMoves[j].file;
         counter++;
       } 
    }
  }
  //surroundingKing stores the positions that can be blocked. It does not check the kings itselfs movement. With just this, king should be in checkmate if there is no piece that may block it and the king cannot move anywhere.
  
  t_chessPiece *tempBoard[8][8];
  for(int i = 0; i < 8; i++){
    for(int j = 0; j < 8; j++){
    
       tempBoard[i][j] = *(chessboard + j + (i * 8)); 
    }
  }
  
  t_chessPiece **chessP = &tempBoard[0][0];
  
  for(int i = 0; i < 8; i++)
  {
    if(moveKing[i].rank == -1)
      {
        break;
      }
    else
      {
        move(chessP, &kingPos, &moveKing[i]);
        int check = inCheck(moverColor, oppColor, chessP, moveLog);
        if(check == 0)
        {
         surroundingKing[counter].rank = moveKing[i].rank;
         surroundingKing[counter].file = moveKing[i].file;
         counter++;
        }
        move(chessP, &moveKing[i], &kingPos);
      }
  }
  
  
    for(int i = 0; i < 8; i++)
  {
//    printf("\n Rank: %d File: %c", surroundingKing[i].rank, surroundingKing[i].file);
    if(surroundingKing[i].rank == -1)
    {
      return 1;
    }
  }
  return 0;
} //EOF checkmate

/*
//Check if King is in check
int isKingInCheck(t_chessPiece *chessboard, char playerColor) {
  t_position kingPos;
  int inCheck = 0;

  // Find the player's king position
    for (int i = 0; i < 8; i++) {
    for (int j = 0; j < 8; j++) {
      t_chessPiece *piece = chessboard + j + (i * 8);
      if (piece != NULL && piece->type == KING && piece->color == playerColor) {
        kingPos.rank = i + 1;
        kingPos.file = intToChar(j);
        break;
      }
    }
  }

// Check if any opponent piece has a legal move that captures the king
  for (int i = 0; i < 8; i++) {
    for (int j = 0; j < 8; j++) {
      t_chessPiece *piece = chessboard + j + (i * 8);
      if (piece != NULL && piece->color != playerColor) {
        t_position pos;
        pos.rank = i + 1;
        pos.file = intToChar(j);
        MOVESET *moves = allLegalMoves(chessboard, &pos);
        for (int k = 0; k < 32; k++) {
          if (moves[k].end.rank == kingPos.rank && moves[k].end.file == kingPos.file) {
            inCheck = 1;
            break;
          }
        }
        free(moves);
        if (inCheck) {
          break;
        }
      }
    }
    if (inCheck) {
      break;
    }
  }

  return inCheck;
}


void inStalemate(t_chessPiece *chessboard)
{
  //no legal moves, but not in check,
  //basically, if not in check, but all squares around the king are threatened i think
  t_position pos;
  int counter3 = 0;
  t_position *playerMoves = malloc(8 * sizeof(t_position));
  for(int i = 0; i < 8; i++){
    for(int j = 0; j < 8; j++){
      if((*(chessboard + j + (i * 8))) != NULL)
      {
        MOVESET *move = malloc(32 * sizeof(MOVESET));
        if((**(chessboard + j + (i * 8))).color != oppColor)
        {
          pos.rank = i + 1;
          pos.file = intToChar(j);
          move = allLegalMoves(chessboard, &pos);
          for(int k = 0; k <32; k++)
          {
            // Add move to playerMoves array
              if (move[k].end.rank != -1) {
                  playerMoves[counter3] = move[k].end;
            		counter3++;
                          }
                         }
			}
                       }
                      }
            
             // Check if any of the legal moves result in the player's king being in check
            int inCheck = isKingInCheck(chessboard, playerColor);
            if (inCheck) {
            	 return;
            }
            // Check if there are no legal moves available
            if (counter3 == 0) {
            printf("The game is in stalemate");
            }
}

*/
