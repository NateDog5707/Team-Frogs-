#include "chessPieces.h"
#include "board.h"
//#include "moveSet.h"
#include "log.h"

#ifndef COMPUTERMOVES_H
#define COMPUTERMOVES_H

typedef struct MoveEntry MOVEENTRY;

typedef struct MoveSet MOVESET;

typedef struct MoveList MOVELIST;

struct MoveSet
{
	unsigned int initial_file;
	unsigned int initial_rank;
	unsigned int final_file;
	unsigned int final_rank;
};


struct MoveEntry
{
	MOVELIST *list;
	MOVEENTRY *prev;
	MOVEENTRY *next;
	MOVESET *moveset;
	unsigned int movevalue;
};



struct MoveList
{
	unsigned int length;
	MOVEENTRY *first;
	MOVEENTRY *last;	
};


void ComputerMoves(t_chessPiece **chessboardFirstP, t_position *initial, t_position *final, char *computerColor, int difficulty, t_logList *moveLog);

MOVELIST *CreateMoveList(void);
void DeleteMoveList(MOVELIST *LIST);
void AppendMoveEntry(MOVELIST *LIST, MOVESET *Moveset);
void DeleteMoveEntry(MOVEENTRY *Moveentry);

void AssignMoveValues(t_chessPiece **chessboardFirstP, MOVELIST *LIST, int compcolor, int playercolor, t_logList *moveLog);
MOVESET *BestMove(t_chessPiece **chessboardFirstP, char *computerColor, int difficulty, t_logList *moveLog);

#endif
