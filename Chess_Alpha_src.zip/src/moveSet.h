#include <stdio.h>
#include "chessPieces.h"
#include "board.h"
#include "computerMoves.h"
#include "log.h"

#ifndef MOVESET_H
#define MOVESET_H


enum fileDef
{
    A = 1,
    B = 2,
    C = 3,
    D = 4,
    E = 5,
    F = 6,
    G = 7,
    H = 8
};

typedef struct move t_move;


struct move
{
    t_position initialPos;
    t_position finalPos;
    t_move *Next;
    t_move *Prev;
};

//not implemented yet
void undo();


int fileToIndice(char file);

char indiceToFile(int indice);

//gets user input for file and rank position of the piece they want to move.
t_position* readMove(t_chessPiece ** chessboard);

t_chessPiece* getPiece(t_chessPiece ** chessboard, t_position* pos);

void allPossibleMoves(t_chessPiece ** chessboard, t_chessPiece* piece, t_position* initial, t_position* all);

//FOR USE
MOVESET* allLegalMoves(t_chessPiece** chessboardP, t_position* initial, t_logList *moveLog); //This function returns an array of all legal moves for a piece at a initial position.

//returns 1 if move is legal, 0 if move is illegal
int isMoveLegal(t_chessPiece ** chessboardP, t_position* initial, t_position* final, t_logList *moveLog);//This function returns an integer if a move is legal depending on the initial and final positions inputted. 1 is returned if legal, 0 is returned if not legal.

#endif 
