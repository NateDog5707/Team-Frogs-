#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <math.h>

// gui?

#include "board.h"
#include "checkStatus.h"
#include "chessPieces.h"
#include "computerMoves.h"
#include "log.h"
#include "moveSet.h"


//implicit declaration stuff
void printMainMenu();

void printPlayerMenu();

void startGame(); // holds the while loop for the game

void offerDraw(char * leavePlayerMenu, int * drawed);

void forfeit(char * leavePlayerMenu, int * forfeited);

void rulesOfChess();

int main(){

	int menuInput;
	char leaveMainMenu = 1;


	//Program start - UI main menu
	
	while (leaveMainMenu == 1)
	{
		printMainMenu();
		scanf("%d", &menuInput);
//	  printf("Try google\n" + menuInput);
		switch(menuInput){
			case 1: //Start game
				printf("\nStarting Game...\n\n");
				//TODO: polish this
				//moved the game loop into its own function so that the program may play multiple games (call the function over and over) without having to exit the program
				startGame();
				
				
				//leaveMainMenu = 0;
				break;
			case 2: //return log file of previous game
				printf("Not implemented yet :(\n");
				//leaveMainMenu = 0;
				break;
			case 3: // rules of chess
		    rulesOfChess();
				//leaveMainMenu = 0;
				break;
			case 4: //exit program
				leaveMainMenu = 0;
				break;
			default:// user inputs smth weird
				printf("Invalid Input!\n\n");
				break; //loops again
		}//switch end
		
		
		
		
		
	}//main menu while end
	leaveMainMenu = 1;


	printf("Exiting program.\n");
	printf("Have a good day! :)\n");




	return 0;

} // End of main() 



//function definitions

void printMainMenu(){

	printf("\t\t\t\tChess\n");
	printf("Main Menu:\n");
	printf("\t1. Start Game\n");
	printf("\t2. Log file\n");
	printf("\t3. Rules of Chess\n");
	printf("\t4. Exit program\n");
	printf("Enter an option: ");
}

void rulesOfChess(){

	printf("\t\t\t\tRules of Chess\n");
	printf("\t1. White moves first and then players take turns moving (only one piece can move at a time)\n");
	printf("\t2. Pieces can only perform their respective moves)\n");
  printf("\tPawn: Moves straight ahead one square at a time (but on the first move has the choice of moving one or two squares forwards) and can only capture diagonally. \n");
  printf("\tKnight: Moves in an L shape (either two squares horzontally or vertically and moe more square to form the L) and can jump over pieces\n");
  printf("\tBishop: Moves any number of squares, but only diagonally and cannot pass over other pieces \n");
  printf("\tRook: Moves in any number of squares vertically or horizontally and cannot pass over other pieces \n");
  printf("\tQueen: Moves in any direction (horizontally, vertically, diagonally) as long as her path is not blocked\n");
  printf("\tKing: Moves in aany direction, but only by one square \n");
	printf("\t3. If an enemy piece is in a position where the king may be captured, the king is in check. \n As such, you must move the king away or move another piece to block the attack\n");
  printf("\t4. King cannot move itself into check\n");
	printf("\t5. If a player cannot stop their opponent from capturing their king on the next turn, it's checkmate and the game is over\n");
	printf("\t6. Promotion: When a pawn reaches the opposit eedge of the board and can be promoted to either a rook, knight, bishop, or queen\n");
  printf("\t7. Castling: The king moves two squares towards the rook, and the rook moves to the square over which the king passed.\n");
  printf("\t8. En Passant: In the case that a pawn piece has not yet moved and it initially moves two spaces forward, any enemy pawn piece that, as a result, is side by side with the first pawn piece, may move to the square behind the first pawn piece and capture it.\n");
}


void startGame(){

	//pregame stuf

	int chooseColor; //1 = White, 2 = Black
	//strings used for printing to screen
	char *playerColor;  
	char *computerColor;
	char *winner = "";
	
	
	//ingame stuff
	
	int menuInput;
//	char leaveInGameMenu = 1;
	char leavePlayerMenu = 1;
	
	int forfeited = 0;
	int drawed = 0;
	


	//entering move stuff

	int inputRank; //for calling move()
	char inputFile;
		
	int firstMoveOK = 1;
	int secondMoveOK = 1;
	
	//input validation
//	int playerInCheck;
	int legalMove = 0;
	
	t_position initPosition;
	t_position finPosition;
	
	//ingame checks
	int cheek = 0; //for check
	int cheekmate = 0;
	
	t_chessPiece *pieceAtFinal = NULL;
	//for log
	
	enum t_pieceType pieceAtInit; 
	enum t_pieceType pieceAtFin;
	t_logList *moveLog = CreateMoveLog();
	
	
	//for move validation (use isLegalMove for move validation)
	//MOVESET *allLegal;
	
	
				
	//------------- Proceeding to start game -----------------
	
	t_chessPiece *chessboardArray[8][8]= {(t_chessPiece*) NULL}; //chessboard declaration is now in main() 4/23/2023
	
	for (int i = 0; i < 8; i++){
		for (int j = 0; j < 8; j++){
			chessboardArray[i][j] = (t_chessPiece *) NULL;
			
		}
	}

	
	t_chessPiece **chessboardFirstP = (t_chessPiece **) NULL; //This might error
	chessboardFirstP =  &chessboardArray[0][0]; //takes first obj pointer

	
	int isBoardInitialized = 0; //flag to initialize the board 
	int *ptrToInitializationFlag = &isBoardInitialized; //pointer for flag, so variable may be edited
	

	displayBoard(chessboardFirstP, ptrToInitializationFlag);   //first display serves as initialization
  isBoardInitialized = 1;
  





	printf("Game start\n");
	
	//player chooses game mode (pvp or pvc) default is pvc
	int game_mode = 1;
	printf("1. Player vs Computer\n");
	printf("2. Player vs Player\n");
	printf("Choose a game mode: ");
	scanf(" %d", &game_mode);
	
	int difficulty = 1;
	if(game_mode == 1)
	{
		//player chooses computer difficulty
		printf("1. Easy Mode\n");
		printf("2. Normal Mode\n");
		printf("Choose the difficulty level: ");
		scanf(" %d", &difficulty);
		difficulty -= 1; // easy = 0 and normal = 1
	}
	
	
	//player chooses color
	printf("1. White\n");
	printf("2. Black\n");
	printf("Choose your color: ");
	scanf(" %d", &chooseColor); // use THIS VARIABLE to check whether or not the user can move black or white pieces.
	// note: added space before %c so that it could scan input properly
	
	if (chooseColor == 1){ //user is white
		playerColor = "White";
		computerColor = "Black";
	}
	else{ //chooseColor == 0, user is black
		playerColor = "Black";
		computerColor = "White";	
	}
	
	
	
	//if, computer is white player, put computer moves here!
	
	if (chooseColor != 1) //player chooses black, computer moves first
	{
		printf("%s's turn!\n", computerColor);

//		printf("initial computer moves here\n");
		
		ComputerMoves(chessboardFirstP, &initPosition, &finPosition, computerColor, difficulty, moveLog); // doesnt contain move() or log stuff, only changes init and fin positions for main to use
			
			//--------log stuff
		pieceAtInit = (*getPiece(chessboardFirstP, &initPosition)).pieceType;
		if (getPiece(chessboardFirstP, &finPosition) != NULL){
			pieceAtFin = (*getPiece(chessboardFirstP, &finPosition)).pieceType;
		}
		else{
			pieceAtFin = None;
		}
//		printf("in main, before appendMove\n");
		AppendMove(moveLog, &initPosition, &finPosition, pieceAtInit, pieceAtFin); //log.c
		//PrintLog(moveLog, playerColor, computerColor);
		
//		printf("Getting the latest move:\n");
		GetLastMove(moveLog);
						
		//----- end log stuff
	
		move(chessboardFirstP, &initPosition, &finPosition);
		
		
		displayBoard(chessboardFirstP, ptrToInitializationFlag);
		
		// NO NEED TO CHECK FOR CHECK OR CHECKMATE ON COMPUTER'S FIRST MOVE!
	
	
	}
	
	
	//-------------- Game loop ---------------
	while ( !forfeited && !drawed && !cheekmate ) { //change this to "while game is on going, while checkmate hasn't been reached, while !forfeited, while !draw
	
		//User's Turn
		printf("\n%s's turn!\n", playerColor);
	
		while (leavePlayerMenu == 1){//in game menu select
			
			while (getchar() != '\n'){//flushes out buffer
				continue;
			}
			printPlayerMenu();
  		scanf("%d", &menuInput);
  		
  	
			switch (menuInput){
				case 1: //Move a piece, proceed through the loop
					
					
					
				while(legalMove == 0)
				{
					legalMove = 1;
					
					
					while(firstMoveOK == 1)
					{
						
						while (getchar() != '\n'){
							continue;
						}
						
						printf("Enter initial position: ");
						scanf(" %c %d", &inputFile, &inputRank);
						//printf("initial: %c, %d, typeofs: %s, %s", inputFile, inputRank, typeof(inputFile), typeof(inputRank)); //debug
						
						if (inputRank >= 1 && inputRank <= 8 && inputFile >= 'a' && inputFile <= 'h'){
							initPosition.rank = inputRank;
							initPosition.file = inputFile;
						}
						else{
							printf("Error: Input position is not within bounds!\n");
							continue;
						}
						
						//making sure the user selects their own piece to move and not an opponent's piece; if statement checks if the selected piece is NOT the same color
						if  (getPiece(chessboardFirstP, &initPosition) == NULL){
							printf("Error: No piece at indicated position!\n");
							continue; //hopefully this goes back to beginning of firstMoveOK
						}
						else if ( (getPiece(chessboardFirstP, &initPosition)->color == White && chooseColor != 1) || (getPiece(chessboardFirstP, &initPosition)->color == Black && chooseColor ==1))
						{
							printf("Error: Selected piece is not your own!\n");
							continue; //hopefully this goes back to beginning of firstMoveOK
						}
						
						else{
							firstMoveOK = 0; //
						}
					} //firstMoveOK while end
					firstMoveOK = 1;
						
						
					while(secondMoveOK == 1){	
					
						while (getchar() != '\n'){
							continue;
						}
						
						printf("\nEnter final position: ");
						scanf(" %c %d", &inputFile, &inputRank);
						
						
						finPosition.rank = inputRank;
						finPosition.file = inputFile;
     				
     				
						if (inputRank >= 1 && inputRank <= 8 && inputFile >= 'a' && inputFile <= 'h'){
							finPosition.rank = inputRank;
							finPosition.file = inputFile;
						}
						else{
							printf("Error: Input position is not within bounds!\n");
							continue;
						}
						
						//CHECKING IF POSITION FOLLOWS LEGALITY
						
						//isMoveLegal returns 0 if illegal, 1 if legal
						legalMove = isMoveLegal(chessboardFirstP, &initPosition, &finPosition, moveLog);
						
						if (legalMove == 0) {
							printf("Error: Your move is illegal!\n");
							secondMoveOK = 0; //to leave the secondMove loop and go back to firstmove loop
							firstMoveOK = 1;
							continue;
						}
						
						
						pieceAtFinal = getPiece(chessboardFirstP, &finPosition);
						
						
						
						pieceAtInit = (*getPiece(chessboardFirstP, &initPosition)).pieceType;
						if (getPiece(chessboardFirstP, &finPosition) != NULL){
							pieceAtFin = (*getPiece(chessboardFirstP, &finPosition)).pieceType;
						}
						else{
							pieceAtFin = None;
						}
			
						//THIS MOVE IS TO CHECK FOR CHECK ON THE USER
						
						AppendMove(moveLog, &initPosition, &finPosition, pieceAtInit, pieceAtFin);
							move(chessboardFirstP, &initPosition, &finPosition);
							//printf("if big if \n");
							if( chooseColor == 1 && inCheck(0, 1, chessboardFirstP, moveLog) > 0){ //if team white and in check returns >0, we want to say that the move is not legal
								printf("Error: Your king is in check!\n");
								UndoMove(moveLog, chessboardFirstP, pieceAtFinal);
								secondMoveOK = 0;
								firstMoveOK = 1;
								legalMove = 0;
								continue;
							}
							else if (chooseColor == 0 && inCheck (1,0, chessboardFirstP, moveLog) > 0){
								printf("Error: Your king is in check!\n");
								UndoMove(moveLog, chessboardFirstP, pieceAtFinal);
								secondMoveOK = 0;
								firstMoveOK = 1;
								legalMove = 0;
								continue;
							}
							else{
								//printf("edejdoei\n");
								UndoMove(moveLog, chessboardFirstP, pieceAtFinal);
							}
						
						
						
						
						
						
//            printf("use isMoveLegal for input validation. 0 is illegal, 1 is legal.\n Legal Move: %d\n", legalMove);
//     				printf("in main, before calling allLegal\n");
     				//debugging allLegalMoves(board is printed again in this function)
//            allLegal = allLegalMoves(chessboardFirstP, &initPosition, moveLog);  
//     				printf("in main, after calling allLegal\n");
            
            
						

						//lots of if statements to see if the move is legal and passes all checks, and THEN move();
						//checks: inputted position is a legal position; if in check, gets out of check;
								



						//if move was successful, leave player menu and pass turn to computer
						//add to log
						
						
						
						//-----------------    	log stuff
						pieceAtInit = (*getPiece(chessboardFirstP, &initPosition)).pieceType;
						if (getPiece(chessboardFirstP, &finPosition) != NULL){
							pieceAtFin = (*getPiece(chessboardFirstP, &finPosition)).pieceType;
						}
						else{
							pieceAtFin = None;
						}
			

						moveLog = AppendMove(moveLog, &initPosition, &finPosition, pieceAtInit, pieceAtFin);  //log.c
						//PrintLog(moveLog, playerColor, computerColor);
						
//						printf("Getting the latest move:\n");
						GetLastMove(moveLog);
						
						//-----------         end log stuff
		
//						printf("DEBUG IN MAIN BEFORE MOVE\n"); 
						move(chessboardFirstP, &initPosition, &finPosition);
		
						 
						 
						// displayBoard(chessboardFirstP, ptrToInitializationFlag);
     	      
     	      
     	      secondMoveOK = 0;
  	      }//while secondMove end
  	      secondMoveOK = 1;
     	      
     	  }//while legalMove end, requires legalMove = 1 to leave
				legalMove = 0;

					//DEBUG FOR CHECK-----------
					//check for PLAYER check
				if (chooseColor == 1)
				{
					cheek = inCheck(1, 0, chessboardFirstP, moveLog); //run the white check for black king

					if (cheek>0){
						printf("\n%s King do be in check\n", computerColor);	
							
						cheekmate = inCheckmate(0, chessboardFirstP, moveLog);
					}
					else{
						printf("%s King NOT in check sadge\n", computerColor);
					}
				}
				else
				{
					cheek = inCheck(0, 1, chessboardFirstP, moveLog); //run the black check for white king
						 
					if (cheek>0){
						printf("\n%s King do be in check\n", computerColor);	
							
						cheekmate = inCheckmate(1, chessboardFirstP, moveLog);
					}
					else{
						printf("%s King NOT in check\n", computerColor);
					}
				}
				
				if (cheekmate > 0){
					//leave game
						 displayBoard(chessboardFirstP, ptrToInitializationFlag);  
						printf("%s is in checkmate!\n", computerColor);
						winner = playerColor;
						leavePlayerMenu  = 0;
						break;
				}
				
					
//					UndoMove(moveLog, chessboardFirstP); //----------------------special
					
					
					leavePlayerMenu = 0;
					
					break;
				case 2: //Undo last turn
					printf("To be implemented\n");
					
					break;
				case 3: //Check game log
					//printGameLog(); // in log.h or log.c
					PrintLog(moveLog, playerColor, computerColor);
					break;
				case 4: // Offer Draw
					offerDraw(&leavePlayerMenu, &drawed);
					//IF SUCCESSFUL, EXIT GAME LOOP
					break;
				case 5: //Forfeit
					forfeit(&leavePlayerMenu, &forfeited);
					//EXIT GAME LOOP
					leavePlayerMenu = 0;
					
					break;
				default: //user inputs smth expected, redo loop
					printf("Error: Invalid input!\n");
					break;
	
			} //switch end
	
		
	
		} //PlayerMenu while end
		leavePlayerMenu = 1;
		
		if (forfeited == 1 || drawed == 1 || cheekmate == 1){
			leavePlayerMenu = 0;
			break;
		}
		
		
		displayBoard(chessboardFirstP, ptrToInitializationFlag);  
		

		
		//------------Computer's turn, calls computer functions-------------
		
		printf("%s's turn!\n", computerColor);

		
		//PVC GAME MODE
		if(game_mode == 1)
		{
//			printf("computer moves here\n");
		
			ComputerMoves(chessboardFirstP, &initPosition, &finPosition, computerColor, difficulty, moveLog); // doesnt contain move() or log stuff, only changes init and fin positions for main to use
			
			//--------log stuff
		pieceAtInit = (*getPiece(chessboardFirstP, &initPosition)).pieceType;
		if (getPiece(chessboardFirstP, &finPosition) != NULL){
			pieceAtFin = (*getPiece(chessboardFirstP, &finPosition)).pieceType;
		}
		else{
			pieceAtFin = None;
		}
//		printf("in main, before appendMove\n");
		AppendMove(moveLog, &initPosition, &finPosition, pieceAtInit, pieceAtFin); //log.c
		//PrintLog(moveLog, playerColor, computerColor);
		
//		printf("Getting the latest move:\n");
		GetLastMove(moveLog);
						
		//----- end log stuff
	
		move(chessboardFirstP, &initPosition, &finPosition);
		
		
//		printf("DEBUG IN MAIN, BEFORE COMPUTER inCheck()\n");
		//------ COMPUTER CHECK------
		cheek = 0;
		
			if (chooseColor == 1)//if player chose white, run check for white
			{ 
			
				cheek = inCheck(0, 1, chessboardFirstP, moveLog);
			
				if (cheek>0){
					printf("\n%s King do be in check\n", playerColor);	
							
					cheekmate = inCheckmate(1, chessboardFirstP, moveLog);
				}
				else{
					printf("%s King NOT in check sadge\n", playerColor);
				}
		
			}
			else
			{
				cheek = inCheck(1, 0, chessboardFirstP, moveLog); //player chose black, run check for black king
		
				if (cheek>0){
					printf("\n%s King do be in check\n", playerColor);	
							
					cheekmate = inCheckmate(0, chessboardFirstP, moveLog);
				}
				else{
					printf("%s King NOT in check sadge\n", playerColor);
				}
		
			}
		
		
				if (cheekmate > 0){
					//leave game
							displayBoard(chessboardFirstP, ptrToInitializationFlag);  
					printf("%s is in checkmate!\n", playerColor);
					winner = computerColor;
					return;
				}
			
		
		
		
			//----------------end computer turn--------------------------
			
		
		
			displayBoard(chessboardFirstP, ptrToInitializationFlag);  




		//---------------PLAYER 2 TURN----------------------------

		//debug
		//printf("forfeited out of function: %d\n", forfeited);
		}
		//PVP GAME MODE
		else if(game_mode == 2)
		{
//			printf("player 2 moves here\n");
			
			while (leavePlayerMenu == 1){//in game menu select
			
			while (getchar() != '\n'){//flushes out buffer
				continue;
			}
			printPlayerMenu();
  		scanf("%d", &menuInput);
  		
  	
			switch (menuInput){
				case 1: //Move a piece, proceed through the loop
					
					while(legalMove == 0)
					{
					
					
						while(firstMoveOK == 1){
						
							while (getchar() != '\n'){
									continue;
							}
							
							printf("Enter initial position: ");
							scanf(" %c %d", &inputFile, &inputRank);
							//printf("initial: %c, %d, typeofs: %s, %s", inputFile, inputRank, typeof(inputFile), typeof(inputRank)); //debug
							
							if (inputRank >= 1 && inputRank <= 8 && inputFile >= 'a' && inputFile <= 'h'){
								initPosition.rank = inputRank;
								initPosition.file = inputFile;
							}
							else{
								printf("Error: Input position is not within bounds!\n");
								continue;
							}
							
							//making sure the user selects their own piece to move and not an opponent's piece; if statement checks if the selected piece is NOT the same color
							if  (getPiece(chessboardFirstP, &initPosition) == NULL){
								printf("Error: No piece at indicated position!\n");
								continue; //hopefully this goes back to beginning of firstMoveOK
							}
							else if ( (getPiece(chessboardFirstP, &initPosition)->color == White && chooseColor != 0) || (getPiece(chessboardFirstP, &initPosition)->color == Black && chooseColor == 0))
							{
								printf("Error: Selected piece is not your own!\n");
								continue; //hopefully this goes back to beginning of firstMoveOK
							}
							
							else{
								firstMoveOK = 0; //
							}
						} //firstMoveOK while end
						firstMoveOK = 1;
							
 							
							
						while(secondMoveOK == 1){	
						
							while (getchar() != '\n'){
								continue;
							}
							
							printf("\nEnter final position: ");
							scanf(" %c %d", &inputFile, &inputRank);
							
							
							finPosition.rank = inputRank;
							finPosition.file = inputFile;
     					
     					
							if (inputRank >= 1 && inputRank <= 8 && inputFile >= 'a' && inputFile <= 'h'){
								finPosition.rank = inputRank;
								finPosition.file = inputFile;
							}
							else{
								printf("Error: Input position is not within bounds!\n");
								continue;
							}
							
							legalMove = isMoveLegal(chessboardFirstP, &initPosition, &finPosition, moveLog);
							
							if (legalMove == 0){
								printf("Error: Your move is illegal!\n");
								firstMoveOK = 1;
								secondMoveOK = 0;
								continue;
							}
       	     //allLegal = allLegalMoves(chessboardFirstP, &initPosition, moveLog);  				

						pieceAtFinal = getPiece(chessboardFirstP, &finPosition);
						
						pieceAtInit = (*getPiece(chessboardFirstP, &initPosition)).pieceType;
						if (getPiece(chessboardFirstP, &finPosition) != NULL){
							pieceAtFin = (*getPiece(chessboardFirstP, &finPosition)).pieceType;
						}
						else{
							pieceAtFin = None;
						}
			
						//THIS MOVE IS TO CHECK FOR CHECK ON THE USER
						
						AppendMove(moveLog, &initPosition, &finPosition, pieceAtInit, pieceAtFin);
							move(chessboardFirstP, &initPosition, &finPosition);
							//printf("if big if \n");
							if( chooseColor != 1 && inCheck(0, 1, chessboardFirstP, moveLog) > 0){ //if team black, we want to see if black king is in check
								printf("Error: Your king is in check!\n");
								UndoMove(moveLog, chessboardFirstP, pieceAtFinal);
								secondMoveOK = 0;
								firstMoveOK = 1;
								legalMove = 0;
								continue;
							}
							else if (chooseColor == 1 && inCheck (1,0, chessboardFirstP, moveLog) > 0){
								printf("Error: Your king is in check!\n");
								UndoMove(moveLog, chessboardFirstP, pieceAtFinal);
								secondMoveOK = 0;
								firstMoveOK = 1;
								legalMove = 0;
								continue;
							}
							else{
								//printf("edejdoei\n");
								UndoMove(moveLog, chessboardFirstP, pieceAtFinal);
							}







						
						
							//-----------------    	log stuff
							pieceAtInit = (*getPiece(chessboardFirstP, &initPosition)).pieceType;
							if (getPiece(chessboardFirstP, &finPosition) != NULL){
								pieceAtFin = (*getPiece(chessboardFirstP, &finPosition)).pieceType;
							}
							else{
								pieceAtFin = None;
							}
									

							moveLog = AppendMove(moveLog, &initPosition, &finPosition, pieceAtInit, pieceAtFin);  //log.c
							//PrintLog(moveLog, playerColor, computerColor);
							
//							printf("Getting the latest move:\n");
							GetLastMove(moveLog);
							
							//-----------         end log stuff
			
			
							move(chessboardFirstP, &initPosition, &finPosition);
 	 
 	    	      secondMoveOK = 0;
 	 		      }//while secondMove end
    	      secondMoveOK = 1;
 	    	      
					}//while legalMove end
					legalMove = 0;

					//DEBUG FOR CHECK-----------
					//check for PLAYER check
				if (chooseColor == 1)
				{
					cheek = inCheck(1, 0, chessboardFirstP, moveLog); //run the white check for black king

					if (cheek>0){
						printf("\n%s King do be in check\n", computerColor);	
							
						cheekmate = inCheckmate(0, chessboardFirstP, moveLog);
					}
					else{
						printf("%s King NOT in check sadge\n", computerColor);
					}
				}
				else
				{
					cheek = inCheck(0, 1, chessboardFirstP, moveLog); //run the black check for white king
						 
					if (cheek>0){
						printf("\n%s King do be in check\n", computerColor);	
							
						cheekmate = inCheckmate(1, chessboardFirstP, moveLog);
					}
					else{
						printf("%s King NOT in check sadge\n", computerColor);
					}
				}
				
				if (cheekmate > 0){
					//leave game
								displayBoard(chessboardFirstP, ptrToInitializationFlag);  
						printf("%s is in checkmate!\n", playerColor);
						winner = computerColor;
						leavePlayerMenu  = 0;
						break;
				}
				
					
					
					
					leavePlayerMenu = 0;
					
					break;
				case 2: //Undo last turn
					printf("To be implemented\n");
					
					break;
				case 3: //Check game log
					//printGameLog(); // in log.h or log.c
					PrintLog(moveLog, playerColor, computerColor);
					break;
				case 4: // Offer Draw
					offerDraw(&leavePlayerMenu, &drawed);
					//IF SUCCESSFUL, EXIT GAME LOOP
					break;
				case 5: //Forfeit
					forfeit(&leavePlayerMenu, &forfeited);
					//EXIT GAME LOOP
					leavePlayerMenu = 0;
					
					break;
				default: //user inputs smth expected, redo loop
					printf("Error: Invalid input!\n");
					break;
	
			} //switch end
	
		
	
		} //PlayerMenu while end
		leavePlayerMenu = 1;
		
		if (forfeited == 1 || drawed == 1 || cheekmate == 1){
			leavePlayerMenu = 0;
			break;
		}
		
		
		displayBoard(chessboardFirstP, ptrToInitializationFlag);  
		
		}
		
		//end of implementing pvp

		
		
		
	}// game while end  ------- EXIT OF GAME -----
 
 
	if (strcmp(winner, "") == 0){ //forfeited
		if (forfeited == 1){
			winner = computerColor; //wrong but too lazy
		}
		if (drawed == 1){
			winner = "Draw!\nNobody";
		}
	}

	
	printf("Game Over!\n%s Wins!\n", winner);
	
	
	
	//if there have been moves made, create a log about it
	if (moveLog->First != NULL){ 
		LogToTxt(moveLog, playerColor, computerColor, winner);
	}
	//printf("after logtotext\n");
	//---------========== FREES GO HERE ===========-----------
	
	DeleteMoveLog(moveLog); //calls DeleteMove for each move in the log
	//printf("after deletemovelog\n");


}// startGame() end






void printPlayerMenu(){

	printf("\t\t\t\tYour Turn\n");
	printf("\t1. Move a piece\n");
	printf("\t2. Undo last turn\n");
	printf("\t3. Check Game Log\n");
	printf("\t4. Offer Draw\n");
	printf("\t5. Forfeit\n");
	printf("Enter an option: ");
}




void offerDraw(char * leavePlayerMenu, int * drawed){
	int userInput;
	
	printf("Would you like to offer a draw?\n");
	printf("\t1. Yes\n");
	printf("\t2. No\n");
	printf("Enter an option: ");
	
	scanf("%d", &userInput);
	
	if (userInput == 1){
		//request computer draw. flip a coin?
		//*leaveInGameMenu = 0;
		
		*drawed = 1;
		
		*leavePlayerMenu = 0;
	}
	
	
} //offerDraw() end

void forfeit(char * leavePlayerMenu, int * forfeited){
	int userInput;
	
	printf("\nWould you like to forfeit?\n");
	printf("\t1. Yes\n"); 
	printf("\t2. No\n");
	printf("Enter an option: ");
	
	scanf("%d", &userInput);
	
	if (userInput == 1){
		*leavePlayerMenu = 0;
		*forfeited = 1;
		//printf("forfeited = %d\n", forfeited);
	}

} //forfeit() end
