#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <math.h>

#include "log.h"




t_logList *CreateMoveLog(){

	t_logList *moveLog;
	moveLog = (t_logList *)malloc(sizeof(t_logList));
	if(!moveLog){
		return NULL;
	}
	moveLog->Length = 0;
	moveLog->First = NULL;
	moveLog->Last = NULL;

	return moveLog;
}


void DeleteMoveLog(t_logList *moveLog){

	assert(moveLog);
	assert(moveLog->First);
//printf("A\n");	
	t_movemade *current = moveLog->First;
	t_movemade *next = current->Next;
//printf("B\n");	
	do{
	
		next = current->Next;
		DeleteMove(current);
//printf("Deleted a move from log\n");
		current = next;
	} while (next != NULL);
	
	moveLog->First = NULL;
	moveLog->Last = NULL;

	free(moveLog);
}


t_movemade *CreateMove(t_position *initial, t_position *final, enum t_pieceType movingPiece, enum t_pieceType endPiece){

	//creating a newmove and loading in values
		
		t_movemade *newMove = (t_movemade *)malloc(sizeof(t_movemade));
		
		if (!newMove){
			return NULL;
		}
		
		newMove->pieceAtInitial = movingPiece;
		newMove->pieceAtFinal = endPiece;

		/*
		newMove->initialPos = (t_position *)malloc(sizeof(t_position));
		if (!newMove->initialPos){
			free(newMove);
			return NULL;
		}
		newMove->finalPos = (t_position *)malloc(sizeof(t_position));
		if (!newMove->finalPos){
			free(newMove->initialPos);
			free(newMove);
			return NULL;
		}
		*/
		
		newMove->initialPos = *initial;
		newMove->finalPos = *final;	

		newMove->Next = NULL;
		newMove->Prev = NULL;

		return newMove;
}








t_logList *AppendMove(t_logList *moveLog, t_position *initial, t_position *final, enum t_pieceType movingPiece, enum t_pieceType endPiece){

		assert(moveLog);
		
		t_movemade *newMove = CreateMove(initial, final, movingPiece, endPiece);

		//appending
		
		newMove->List = moveLog;
		newMove->Next = NULL;
		
		if (moveLog->Last == NULL){
			moveLog->First = newMove;
			moveLog->Last = newMove;
			newMove->Prev = NULL;
			moveLog->Length = 1;
		}
		else{
			moveLog->Last->Next = newMove;
			newMove->Prev = moveLog->Last;
			moveLog->Last = newMove;
			
			moveLog->Length++;
		}
		return moveLog;
} //appendMove EOF





void DeleteMove(t_movemade *currMove){

		assert(currMove);
		
		//currMove->Prev->Next = NULL; i think this line was causing errors in valgrind
		if (currMove->Prev != NULL){
			currMove->Prev->Next = NULL;
		}
		currMove->Prev = NULL;
		currMove->Next = NULL;
		
		currMove->List = NULL;
		
		free(currMove);
		currMove = NULL;
		

}

void UndoMove(t_logList *moveLog, t_chessPiece ** chessboard, t_chessPiece *restore){

	assert(moveLog);
	
		t_movemade *current = moveLog->Last;

	
//	printf("INSIDE UNDO MOVE %d\n", current->finalPos.file-97);
	
	t_position initial = current->initialPos;
	t_chessPiece *pieceAtPos = *(chessboard + (current->finalPos.file-97) + ((current->finalPos.rank-1) *8));
//	printf("%d %d\n", (current->finalPos.file-97), (current->finalPos.rank-1));
	

	
//		displayBoard(chessboard,1 );
	*(chessboard + (current->finalPos.file-97) + ((current->finalPos.rank-1) *8)) = restore;
	*(chessboard + (initial.file-97) + ((initial.rank-1)*8)) = pieceAtPos;
//		displayBoard(chessboard,1);
//	printf("initial.file = %d, initial.rank = %d\n", initial.file-97, initial.rank-1);
	
	DeleteMove(current);
	
}






t_movemade *GetLastMove(t_logList *moveLog){
	//DEBUG
	if (moveLog->Last != NULL){
//		printf("Last Move: initPos = %c%d, finPos = %c%d\n", moveLog->Last->initialPos.file, moveLog->Last->initialPos.rank, moveLog->Last->finalPos.file, moveLog->Last->finalPos.rank);
		return moveLog->Last;
	}
	return NULL;

}







void PrintLog(t_logList *moveLog, char *playerColor, char *computerColor){

	assert(moveLog);
	if (moveLog->Length > 1){
		assert(moveLog->First != moveLog->First->Next);
		assert(( ((*(moveLog->First)).initialPos).rank != ((*(moveLog->First->Next)).initialPos).rank) && ( ((*(moveLog->First)).initialPos).file != ((*(moveLog->First->Next)).initialPos).file));
	}
	
	t_movemade *temp = moveLog->First;
	char *pieceName;
	char *pieceName2;
	
	int count = 1;
	
	printf("LOG:\nPlayer picks %s\n", playerColor);
		
	//printf("moveLog->Length = %d\n", moveLog->Length);
	
	
	while (temp != NULL){
		//printf("address of node at count %d: %d\n", count, temp);
		
		switch(temp->pieceAtInitial){
			case 0:
				pieceName = "Pawn";
				break;
			case 1:
				pieceName = "Rook";
				break;
			case 2:
				pieceName = "Knight";
				break;
			case 3:
				pieceName = "Bishop";
				break;
			case 4:
				pieceName = "Queen";
				break;
			case 5:
				pieceName = "King";
				break;
			case 6:
			default:
				pieceName = "None";
				break;
			}//switch end
		switch(temp->pieceAtFinal){
			case 0:
				pieceName2 = "Pawn";
				break;
			case 1:
				pieceName2 = "Rook";
				break;
			case 2:
				pieceName2 = "Knight";
				break;
			case 3:
				pieceName2 = "Bishop";
				break;
			case 4:
				pieceName2 = "Queen";
				break;
			case 5:
				pieceName2 = "King";
				break;
			case 6:
			default:
				pieceName2 = "None";
				break;
			}//switch end
		

			
			
		
		
		if (count %2 ==1){
			printf("Turn %d: White moved %s from %c%d to %c%d", count, pieceName, temp->initialPos.file, temp->initialPos.rank, temp->finalPos.file, temp->finalPos.rank); 
			if (temp->pieceAtFinal != None){
				printf(" - Captured Black %s", pieceName2);
			}
			//if (Black in check), add a tag
			
			
			printf("\n");
		}
		else{
			printf("Turn %d: Black moved %s from %c%d to %c%d", count, pieceName, temp->initialPos.file, temp->initialPos.rank, temp->finalPos.file, temp->finalPos.rank);
			if (temp->pieceAtFinal != None){
				printf(" - Captured White %s", pieceName2);
			}
			
			//if (White in check), add a tag
			
			printf("\n");
		}
		temp = temp->Next;
		count++;
	}	//while end
	

} //end of PrintLog

 


char *LogToTxt(t_logList *moveLog, char *playerColor, char *computerColor, char *winner){

	FILE *txtFile;
	txtFile = fopen("Chess_Log_File.txt", "w");
	char *statement = "";	
	t_movemade *temp = moveLog->First;
	
	
	char *pieceName;
	char *pieceName2;
	
	int count = 1;
	
	fprintf(txtFile, "LOG:\nPlayer picks %s\n", playerColor);
		
	//printf("moveLog->Length = %d\n", moveLog->Length);
	
	
	while (temp != NULL){
		//printf("address of node at count %d: %d\n", count, temp);
		
		switch(temp->pieceAtInitial){
			case 0:
				pieceName = "Pawn";
				break;
			case 1:
				pieceName = "Rook";
				break;
			case 2:
				pieceName = "Knight";
				break;
			case 3:
				pieceName = "Bishop";
				break;
			case 4:
				pieceName = "Queen";
				break;
			case 5:
				pieceName = "King";
				break;
			case 6:
			default:
				pieceName = "ERROR";
				break;
			}//switch end
		switch(temp->pieceAtFinal){
			case 0:
				pieceName2 = "Pawn";
				break;
			case 1:
				pieceName2 = "Rook";
				break;
			case 2:
				pieceName2 = "Knight";
				break;
			case 3:
				pieceName2 = "Bishop";
				break;
			case 4:
				pieceName2 = "Queen";
				break;
			case 5:
				pieceName2 = "King";
				break;
			case 6:
			default:
				pieceName2 = "None";
				break;
			}//switch end
		

		
		if (count %2 ==1){
			fprintf(txtFile, "Turn %d: White moved %s from %c%d to %c%d", count, pieceName, temp->initialPos.file, temp->initialPos.rank, temp->finalPos.file, temp->finalPos.rank); 
			if (temp->pieceAtFinal != None){
				fprintf(txtFile, " - Captured Black %s", pieceName2);
			}
			//if (Black in check), add a tag
			
			fprintf(txtFile, "\n");
		}
		else{
			fprintf(txtFile, "Turn %d: Black moved %s from %c%d to %c%d", count, pieceName, temp->initialPos.file, temp->initialPos.rank, temp->finalPos.file, temp->finalPos.rank);
			if (temp->pieceAtFinal != None){
				fprintf(txtFile, " - Captured White %s", pieceName2);
			}
			//if (White in check), add a tag
			
			fprintf(txtFile, "\n");
		}
		temp = temp->Next;
		count++;
	} //while end
	
	
	fprintf(txtFile, "\nGame Over! %s Wins!\n", winner);
	
	

	
	fclose(txtFile);
	return statement;


}



