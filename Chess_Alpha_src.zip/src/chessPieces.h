
/*
	contains enum pieceTyped(
	contains enum player
	contains struct t_chessPiece


*/

#ifndef CHESSPIECES_H
#define CHESSPIECES_H

enum t_pieceType {
	Pawn = 0, Rook = 1, Knight = 2, Bishop = 3, Queen = 4, King = 5, None = 6
	};
	
enum player {
	Black = 0, White = 1 
	};

typedef struct chessPiece {
	enum t_pieceType pieceType;
	enum player color;
	int hasMoved; // 0 = hasn't moved, 1 = has moved
	
} t_chessPiece;

//currently, there are no functions for chessPieces module
//initialization of chessPieces is moved to board.h inside instantiateBoard()


#endif