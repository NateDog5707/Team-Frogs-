#include <stdio.h>
#include <GUI.h>

/*

//Widgets for gtk to use
GtkWidget *window=NULL;//the window
GtkWidget *image=NULL;//the widget to load image
GtkWidget *layout=NULL;//the layout to put on background and contain fixed widget
GtkWidget *fixed=NULL;//the widget to contain table
GtkWidget *table=NULL;//the widget to contain icons

char *str_square[2]={"./chess_icon/WhiteSquare.jpg","./chess_icon/BlackSquare.jpg"};
char *str_piece[24]={"BB_BB.jpg", "BB_WB.jpg", "BFK_BB.jpg",""};

//init the window and start the main gtk loop
void gui_init_window(int argc, char*argv[])
{
    if(window!=NULL)return;
    gtk_init(&argc, &argv) ;
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL) ;
    gtk_widget_set_size_request(window, WINDOW_WIDTH, WINDOW_HEIGHT) ; 
    gtk_container_set_border_width (GTK_CONTAINER(window), WINDOW_BORDER) ;
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER) ; 
    gtk_window_set_title(GTK_WINDOW(window), "TEAM FROG!");
    gtk_window_set_resizable(GTK_WINDOW(window), FALSE);
    layout = gtk_layout_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER (window), layout);





}

*/
