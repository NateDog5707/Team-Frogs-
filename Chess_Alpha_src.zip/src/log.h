#include "chessPieces.h"
#include "board.h"


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef LOG_H
#define LOG_H

typedef struct movemade t_movemade;

typedef struct logList t_logList;


struct movemade {
	t_logList *List;
	enum t_pieceType pieceAtInitial;
	enum t_pieceType pieceAtFinal;
	t_position initialPos;
	t_position finalPos;
	t_movemade *Next;
	t_movemade *Prev;
};


struct logList {
	unsigned int Length;
	t_movemade *First;
	t_movemade *Last;

};



//creates a doubly linked list for move log, malloc()
t_logList *CreateMoveLog();

//deletes move log, free()
void DeleteMoveLog(t_logList *moveLog);

//mallocs and creates a t_movemade
t_movemade *CreateMove(t_position *initial, t_position *final, enum t_pieceType movingPiece, enum t_pieceType endPiece);

//creates a move, which is an entry for our move log, malloc()
t_logList *AppendMove(t_logList *moveLog, t_position *initial, t_position *final, enum t_pieceType movingPiece, enum t_pieceType endPiece);

//deletes a move, free()
void DeleteMove(t_movemade *currMove); 


//undoes the last player move
void UndoMove(t_logList * moveLog, t_chessPiece **chessboard, t_chessPiece *restore); 

//returns the most recent PLAYER move
t_movemade *GetLastMove(t_logList *moveLog);

//prints log to screen
void PrintLog(t_logList *moveLog, char *playerColor, char *computerColor);

//saves log in a .txt file
//void LogToText(t_logList *moveLog, char *playerColor, char *computerColor);

//
char *LogToTxt(t_logList *moveLog, char *playerColor, char *computerColor, char *winner);

#endif
