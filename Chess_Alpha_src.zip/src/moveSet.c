#include <stdio.h>
#include "chessPieces.h"
#include "board.h"
#include "moveSet.h"
#include "computerMoves.h"


int fileToIndice(char file)
{
	int indice = 0;
  switch(file)
	{
		case 'a':
       indice = 0;
			return indice;
		case 'b':
			indice = 1;
			return indice;
		case 'c':
			indice = 2;
			return indice;
		case 'd':
			indice = 3;
			return indice;
		case 'e':
			indice = 4;
			return indice;
		case 'f':
			indice = 5;
			return indice;
		case 'g':
			indice = 6;
			return indice;
		case 'h':
			indice = 7;
			return indice;
  }
  return indice;
}

char indiceToFile(int indice)
{
	char file = 'N';
  switch(indice)
	{
		case 0:
			file = 'a';
			return file;
			break;
		case 1:
			file = 'b';
			return file;
			break;
		case 2:
			file = 'c';
			return file;
			break;
		case 3:
			file = 'd';
			return file;
			break;
		case 4:
			file = 'e';
			return file;
			break;
		case 5:
			file = 'f';
			return file;
			break;
		case 6:
			file = 'g';
			return file;
			break;
		case 7:	
			file = 'h';
			return file;
			break;
	}
	return file;
}


t_chessPiece* getPiece(t_chessPiece ** chessboard, t_position* initial) {
	int initialRank = initial->rank - 1;
	int initialFile = fileToIndice(initial->file);		
    
		t_chessPiece* pieceAtPosition = *(chessboard + initialFile + (initialRank * 8)); // dereferencing the address of the chessboard at index [rank][file]
    return pieceAtPosition;
}


void allPossibleMoves(t_chessPiece ** chessboard, t_chessPiece* piece, t_position* initial, t_position all[])
{
    t_position temp;
    int initialRank = initial->rank - 1;
    int initialFile = fileToIndice(initial->file);
    switch (piece->pieceType)
    {
   	
   	case None: //idk
    	break; 
    case Rook: // r for rook
        {
        int count = 0;
        for (int i = 0; i < 8; i++) // vertically available spaces for rook
          {
              temp.rank = initialRank + 1;
              temp.file = indiceToFile(i);
              all[count] = temp;
              count++;
          }
        
        temp.file = indiceToFile(initialFile); // horizontally available spaces for rook
        for (int j = 0; j < 8; j++)
          {
        		  temp.file = initial->file;
              temp.rank = j + 1;
              all[count] = temp;
              count++;
          }
        }
	  break;	
			
    case Knight: // n for knight
    {
      int i = 0;   

	if((initialRank + 2) < 8 && (initialFile + 1) < 8)
	{
      temp.rank = initialRank + 2 + 1; // knight moves up 2 right 1
      temp.file = indiceToFile(initialFile + 1);
      all[i] = temp;
      i++;
	 
	}
	
 if((initialRank+2) < 8 && (initialFile - 1) >= 0)
	{
    temp.rank = initialRank + 2 + 1; // knight moves up 2 left 1
    temp.file = indiceToFile(initialFile - 1);
    all[i] = temp;
    i++;
	}
       
 if((initialRank + 1) < 8 && (initialFile + 2) < 8)
	{

    temp.rank = initialRank + 1 + 1;  // knight moves right 2 up 1
    temp.file = indiceToFile(initialFile + 2);
    all[i] = temp;
    i++;
	}

	if((initialRank - 1) >= 0 && (initialFile + 2) < 8)
	{//FIXING
     temp.rank = initialRank - 1 + 1; // knight moves right 2 down 1 
     temp.file = indiceToFile(initialFile + 2);
     all[i] = temp;
     i++;
	}
	
	if((initialRank - 2) >= 0 && (initialFile + 1) < 8)
	{
     temp.rank = initialRank - 2 + 1; // knight moves down 2 right 1
     temp.file = indiceToFile(initialFile + 1);
     all[i] = temp;
     i++;
	}

	if((initialRank - 2) >= 0 && (initialFile -1) >= 0)
	{
     temp.rank = initialRank - 2 + 1; // knight moves down 2 left 1
	   temp.file = indiceToFile(initialFile - 1);
     all[i] = temp;
     i++;
	}

	if((initialRank + 1) < 8 && (initialFile - 2) >= 0)
  {
     temp.rank = initialRank + 1 + 1; // knight moves left 2 up 1
     temp.file = indiceToFile(initialFile - 2);
     all[i] = temp;
     i++;
	}

	if((initialRank - 1) >= 0 && (initialFile - 2) >= 0)
	{
     temp.rank = initialRank - 1 + 1; // knight moves left 2 down 1
     temp.file = indiceToFile(initialFile - 2);
     all[i] = temp; 
     i++;    
	}
 
  }
       	break;


    case Bishop: // b for bishop
      {
    	int j = initialRank;
      int k = initialFile;
      int move = 0;
      for(int i = initialFile; i < 8; i++)//up right 
         {
           if( j < 8 && k < 8)
             {
               if(j != initialRank && k != initialFile)
                 {
                   temp.rank = j + 1;
                   temp.file = indiceToFile(k);
                   all[move] = temp;
                   move++;
                 }
               j++;
               k++;
             }
         }
        
     	j = initialRank;
      k = initialFile;
      for(int i = initialFile; i < 8; i++)// down right
         {
           if( j >= 0 && k < 8)
             {
               if(j != initialRank && k != initialFile)
                 {
                   temp.rank = j + 1;
                   temp.file = indiceToFile(k);
                   all[move] = temp;
                   move++;
                 }
               j--;
               k++;
             }
         }
         
     	j = initialRank;
      k = initialFile;
      for(int i = initialFile; i >= 0; i--)//up left
         {
           if( j < 8 && k >= 0)
             {
               if(j != initialRank && k != initialFile)
                 {
                   temp.rank = j + 1;
                   temp.file = indiceToFile(k);
                   all[move] = temp;
                   move++;
                 }
               j++;
               k--;
             }
         }
         
     	j = initialRank;
      k = initialFile;
      for(int i = initialFile; i >=0; i--)//down left
         {
           if( j >= 0 && k >= 0)
             {
               if(j != initialRank && k != initialFile)
                 {
                   temp.rank = j + 1;
                   temp.file = indiceToFile(k);
                   all[move] = temp;
                   move++;
                 }
               j--;
               k--;
             }
         }//271
        break;
      }
        
    case Queen:  
      {                   // q for queen
     	int j = initialRank;
      int k = initialFile;
      int move = 0;
      for(int i = initialFile; i < 8; i++)//up right 
         {
           if( j < 8 && k < 8)
             {
               if(j != initialRank && k != initialFile)
                 {
                   temp.rank = j + 1;
                   temp.file = indiceToFile(k);
                   all[move] = temp;
                   move++;
                 }
               j++;
               k++;
             }
         }
        
     	j = initialRank;
      k = initialFile;
      for(int i = initialFile; i < 8; i++)// down right
         {
           if( j >= 0 && k < 8)
             {
               if(j != initialRank && k != initialFile)
                 {
                   temp.rank = j + 1;
                   temp.file = indiceToFile(k);
                   all[move] = temp;
                   move++;
                 }
               j--;
               k++;
             }
         }
         
     	j = initialRank;
      k = initialFile;
      for(int i = initialFile; i >= 0; i--)//up left
         {
           if( j < 8 && k >= 0)
             {
               if(j != initialRank && k != initialFile)
                 {
                   temp.rank = j + 1;
                   temp.file = indiceToFile(k);
                   all[move] = temp;
                   move++;
                 }
               j++;
               k--;
             }
         }
         
     	j = initialRank;
      k = initialFile;
      for(int i = initialFile; i >= 0; i--)//down left
         {
           if( j >= 0 && k >= 0)
             {
               if(j != initialRank && k != initialFile)
                 {
                   temp.rank = j + 1;
                   temp.file = indiceToFile(k);
                   all[move] = temp;
                   move++;
                 }
               j--;
               k--;
             }
         }
         
        for (int i = 0; i < 8; i++) // horizontally available spaces
          {
         
              temp.rank = initialRank + 1;
              temp.file = indiceToFile(i);
              all[move] = temp;
              move++;
            
          }
          

        temp.file = indiceToFile(initialFile); // vertically available spaces
        for (int j = 0; j < 8; j++)
          {
          
              int rank = j + 1;
              temp.rank = rank;
              all[move] = temp;
              move++;
            
          }
      }
        break;


    case King://need to check for out of bounds   
                        // k for king
      {
        int move = 0;
        if((initialRank + 1) < 8)
        {
    		  temp.rank = initialRank + 1 + 1;
          temp.file = indiceToFile(initialFile); // king move up
          all[move] = temp;
          move++;
        }  
        
        if((initialRank - 1) >= 0)
        {
          temp.rank = initialRank - 1 + 1;
          temp.file = indiceToFile(initialFile);// king move down
          all[move] = temp;
          move++;
        }
        
        if((initialFile + 1) < 8)
        {
				  temp.file = indiceToFile(initialFile + 1);
          temp.rank = initialRank + 1; // king move right
          all[move] = temp;
          move++;
        }
        
        if((initialFile - 1) >= 0)
        {
          temp.rank = initialRank +1;
          temp.file = indiceToFile(initialFile - 1); // king move left
          all[move] = temp;
          move++;
        }
        
        if((initialRank + 1) < 8 && (initialFile + 1) < 8)
          {
            temp.file = indiceToFile(initialFile + 1); // king move upper right
            temp.rank = initialRank + 1 + 1;
            all[move] = temp;
            move++;
          }
          
        if((initialRank + 1) < 8 && (initialFile - 1) >= 0)
          {
            temp.file = indiceToFile(initialFile - 1); // king move upper left
            temp.rank = initialRank + 1 + 1;
            all[move] = temp;
            move++;
          }
        if((initialRank - 1) >= 0 && (initialFile + 1) < 8)
          {
            temp.file = indiceToFile(initialFile + 1); // king move bottom right
            temp.rank = initialRank - 1 + 1;
            all[move] = temp;
            move++;
          }
          
        if((initialRank - 1) >= 0 && (initialFile - 1) >= 0)
          {
            temp.file = indiceToFile(initialFile - 1); // king move bottom right
            temp.rank = initialRank - 1 + 1;
            all[move] = temp;
             move++;
          }
        break;
      }

    case Pawn:                   // p for pawn
      {
        if(piece->color == White)
        {
        int move = 0;
				if (initialRank < 7){
					temp.rank = initialRank + 1 + 1;
        	temp.file = initial->file; // pawn moving up one
        	all[move] = temp;
            move++;
          }
        	if (piece->hasMoved == 0){ // hasMoved = 0 means hasn't moved
        		temp.file = initial->file; 
            temp.rank = initialRank + 2 + 1;
        		all[move] = temp;
             move++;
			  	}
				if(initialFile > 0)
         {
           temp.rank = initialRank + 1 + 1;
           int file = initialFile - 1;
           temp.file = indiceToFile(file);
           all[move] = temp;
             move++;
         } 
         if(initialFile < 7)
         {
           temp.rank = initialRank + 1 + 1;
           int file = initialFile + 1;
           temp.file = indiceToFile(file);
           all[move] = temp;
           move++;
         }
        }
       if(piece->color == Black)
            {
        int move = 0;
				if (initialRank < 7){
					temp.rank = initialRank -1 + 1;
        	temp.file = initial->file; // pawn moving up one
        	all[move] = temp;
            move++;
          }
        	if (piece->hasMoved == 0){ // hasMoved = 0 means hasn't moved
        		temp.file = initial->file; 
            temp.rank = initialRank -2 + 1;
        		all[move] = temp;
             move++;
			  	}
				if(initialFile > 0)
         {
           temp.rank = initialRank - 1 + 1;
           int file = initialFile - 1;
           temp.file = indiceToFile(file);
           all[move] = temp;
             move++;
         } 
         if(initialFile < 7)
         {
           temp.rank = initialRank - 1 + 1;
           int file = initialFile + 1;
           temp.file = indiceToFile(file);
           all[move] = temp;
           move++;
         }
        }  
        break;
      }
    }
   
}//EOF allPossibleMoves




//MOVESET or void type
MOVESET  *allLegalMoves(t_chessPiece** chessboardP, t_position* initial, t_logList *moveLog)//ADD INT PLAYERCOLOR AND CHANGE PARAMS FOR FOR LOOP adding elements to allLegal
{
	MOVESET *allLegal = malloc(32 * sizeof(MOVESET));//returned array of all legal moves for a piece  
	t_position *allMoves = malloc(32 * sizeof(t_position));//array of type position of all possible moves for a piece
  t_chessPiece* piece = getPiece(chessboardP, initial);//piece at given position

 
    for(int i = 0; i < 32; i++)
      {
        allLegal[i].final_rank = -1;
      }
     
    t_position up;
    t_position down;
    t_position left;
    t_position right;
    t_position upLeft;
    t_position upRight;
    t_position downLeft;
    t_position downRight;
 
    allPossibleMoves(chessboardP, piece, initial, allMoves); //fills array of t_position with possible moves for a given piece
    int oppColor;
    if(piece->color == White)
    {  
      oppColor = 0;
    }
    else if(piece->color == Black)
    {
      oppColor = 1;
    }


   
    int counter = 0;
    if(piece->pieceType == Knight)//a knight
      {
        
        
    for(int i = 0; i < 32; i++)
      {
        int allMovesFile = fileToIndice(allMoves[i].file);
        int allMovesRank = allMoves[i].rank - 1;
        
        if(allMoves[i].rank == 0)
          break;
        
        if((*(chessboardP + allMovesFile + (allMovesRank * 8))) == NULL)
          {
	           allLegal[counter].initial_rank = initial->rank - 1;
	           allLegal[counter].initial_file = fileToIndice(initial->file);
	           allLegal[counter].final_rank = (allMoves[i].rank - 1);
	           allLegal[counter].final_file = fileToIndice(allMoves[i].file);
             counter++;
          }
        else if((*(chessboardP + allMovesFile + (allMovesRank * 8))) != NULL)
          {
          if (piece->color != ((**(chessboardP + allMovesFile + (allMovesRank * 8))).color))
            {
              allLegal[counter].initial_rank = initial->rank - 1;
	           allLegal[counter].initial_file = fileToIndice(initial->file);
	           allLegal[counter].final_rank = (allMoves[i].rank - 1);
	           allLegal[counter].final_file = fileToIndice(allMoves[i].file);
             counter++;
            }
          }
      }	
      }//end of knight
      
      else if(piece->pieceType == Pawn)//a pawn
      {
//debug
        if(piece->color == Black)
        {
        	counter = 0;
        	down.rank = -1;
        	down.file = 'N';
        	int initialFile = fileToIndice(initial->file);
        	int initialRank = initial->rank - 1;
        
         	for(int i = initialRank - 1; i >= 0; i--)
        	{
          	if((*(chessboardP + initialFile + (i * 8))) != NULL)
          	{  
              down.rank = i + 1;
              down.file = initial->file;
              break;
          	}
        	}
//         	printf("down.rank = %d", down.rank);
        
        	if(down.rank == -1)
        	{
        	  down.rank = 1;
          	down.file = initial->file;
        	}
           
                                                                                //hmmmmm
        	if((initialFile - 1) >= 0 && (initialFile + 1) < 8 && (initialRank + 1) < 8 && (initialRank - 1) >= 0)
        	{
        
        		for(int i  = 0; i < 32; i++)
        		{
        
        			if((*(chessboardP + (initialFile + 1) + ((initialRank - 1) * 8))) != NULL)
        			{
          			if(piece->color != ((**(chessboardP + (initialFile + 1) + ((initialRank - 1) * 8))).color))
          			{
         					if((allMoves[i].rank - 1) == (initialRank - 1) && fileToIndice(allMoves[i].file) == (initialFile + 1))
            			{
             				allLegal[counter].initial_rank = initial->rank - 1;
	           				allLegal[counter].initial_file = fileToIndice(initial->file);
	           				allLegal[counter].final_rank = (allMoves[i].rank - 1);
	           				allLegal[counter].final_file = fileToIndice(allMoves[i].file);
             				counter++;
            			}
          			}
        			}
          
        
        			if((*(chessboardP + (initialFile - 1) + ((initialRank - 1) * 8))) != NULL)
        			{
          			if(piece->color != ((**(chessboardP + (initialFile - 1) + ((initialRank - 1) * 8))).color))
          			{
         			 		if((allMoves[i].rank - 1) == (initialRank - 1) && fileToIndice(allMoves[i].file) == (initialFile - 1))
            			{	
             				allLegal[counter].initial_rank = initial->rank - 1;
	           				allLegal[counter].initial_file = fileToIndice(initial->file);
	           				allLegal[counter].final_rank = (allMoves[i].rank - 1);
	           				allLegal[counter].final_file = fileToIndice(allMoves[i].file);
             				counter++;
            			}
          			}
        			}      
        		}//end of for loop
     			} 
        	for(int i = 0; i < 32; i++)
					{       
       			if(fileToIndice(allMoves[i].file) == initialFile)
       			{
        			if(allMoves[i].rank > down.rank && allMoves[i].rank < initial->rank)
        			{
        				allLegal[counter].initial_rank = initial->rank - 1;
	           		allLegal[counter].initial_file = fileToIndice(initial->file);
	           		allLegal[counter].final_rank = (allMoves[i].rank - 1);
	           		allLegal[counter].final_file = fileToIndice(allMoves[i].file);
             		counter++;
        			}
       			}
 					}
				}
         
    
    		else if(piece->color == White)
    		{

      		counter = 0;
      		up.rank = -1;
        	up.file = 'N';
        	int initialFile = fileToIndice(initial->file);
        	int initialRank = initial->rank - 1;
        
         	for(int i = initialRank + 1; i < 8; i++)
        	{
          	if((*(chessboardP + initialFile + (i * 8))) != NULL)
          	{  
              up.rank = i + 1;
              up.file = initial->file;
              break;
          	}
        	}
       
        
        	if(up.rank == -1)
        	{
          	up.rank = 8;
          	up.file = initial->file;
        	}
        
        	if((initialFile - 1) >= 0 && (initialFile + 1) < 8 && (initialRank + 1) < 8 && (initialRank - 1) >= 0)
        	{
        
        		for(int i  = 0; i < 32; i++)
        		{
        
        			if((*(chessboardP + (initialFile + 1) + ((initialRank + 1) * 8))) != NULL)
        			{
          			if(piece->color != ((**(chessboardP + (initialFile + 1) + ((initialRank + 1) * 8))).color))
          			{
            			if((allMoves[i].rank - 1) == (initialRank + 1) && fileToIndice(allMoves[i].file) == (initialFile + 1))
            			{		
        				 		allLegal[counter].initial_rank = initial->rank - 1;
	          	 			allLegal[counter].initial_file = fileToIndice(initial->file);
	           				allLegal[counter].final_rank = (allMoves[i].rank - 1);
	           				allLegal[counter].final_file = fileToIndice(allMoves[i].file);
             				counter++;
            			}
          			}
        			}
          
        
        			if((*(chessboardP + (initialFile - 1) + ((initialRank + 1) * 8))) != NULL)
        			{
          			if(piece->color != ((**(chessboardP + (initialFile - 1) + ((initialRank + 1) * 8))).color))
          			{
            			if((allMoves[i].rank - 1) == (initialRank + 1) && fileToIndice(allMoves[i].file) == (initialFile - 1))
            			{
             				allLegal[counter].initial_rank = initial->rank - 1;
				           	allLegal[counter].initial_file = fileToIndice(initial->file);
	           				allLegal[counter].final_rank = (allMoves[i].rank - 1);
	           				allLegal[counter].final_file = fileToIndice(allMoves[i].file);
             				counter++;
            			}
          			}
        			}      
        		}//end of for loop
        
        	}//end of outer if statement
        
           
					for(int i = 0; i < 32; i++)
					{       
       			if(fileToIndice(allMoves[i].file) == initialFile)
 			 			{
        			if(allMoves[i].rank < up.rank && allMoves[i].rank > initial->rank)
        			{
             		allLegal[counter].initial_rank = initial->rank - 1;
	           		allLegal[counter].initial_file = fileToIndice(initial->file);
	           		allLegal[counter].final_rank = (allMoves[i].rank - 1);
	           		allLegal[counter].final_file = fileToIndice(allMoves[i].file);
             		counter++;
        			}
       			}
      		}
    		}
    //en passant 
      
			t_movemade *opp_last_move = GetLastMove(moveLog);
			
			if(opp_last_move != NULL)
			{
				int opp_init_rank = (opp_last_move -> initialPos).rank;
				//char opp_init_file = (opp_last_move -> initialPos).file;
				int opp_final_rank = (opp_last_move -> finalPos).rank;
				char opp_final_file = (opp_last_move -> finalPos).file; 
      
      	//EN PASSANT
  			//en passant to top right
  			if((piece -> color == White) && (initial -> rank == 5) && (*(chessboardP + (fileToIndice(initial->file) + 1) +(5*8)) == NULL))
  			{
  				if((opp_last_move -> pieceAtInitial == Pawn) && (opp_init_rank == 7) && (opp_final_rank == 5) && (initial -> file == (opp_final_file - 1)))
  				{
  					allLegal[counter].initial_rank = initial->rank - 1;
      			allLegal[counter].initial_file = fileToIndice(initial->file);
      			allLegal[counter].final_rank = 5;
      			allLegal[counter].final_file = fileToIndice(initial->file) + 1;
      			counter++;
  				}
  			}
  			//en passant to top left
  			if((piece -> color == White) && (initial -> rank == 5) && (*(chessboardP + (fileToIndice(initial->file) - 1) +(5*8)) == NULL))
  			{
  				if((opp_last_move -> pieceAtInitial == Pawn) && (opp_init_rank == 7) && (opp_final_rank == 5) && (initial -> file == (opp_final_file + 1)))
  				{
  					allLegal[counter].initial_rank = initial->rank - 1;
      			allLegal[counter].initial_file = fileToIndice(initial->file);
      			allLegal[counter].final_rank = 5;
      			allLegal[counter].final_file = fileToIndice(initial->file) - 1;
      			counter++;
  				}
  			}
  			//en passant to bottom right
  			if((piece -> color == Black) && (initial -> rank == 4) && (*(chessboardP + (fileToIndice(initial->file) + 1) +(2*8)) == NULL))
  			{
  				if((opp_last_move -> pieceAtInitial == Pawn) && (opp_init_rank == 2) && (opp_final_rank == 4) && (initial -> file == (opp_final_file - 1)))
  				{
  					allLegal[counter].initial_rank = initial->rank - 1;
      			allLegal[counter].initial_file = fileToIndice(initial->file);
      			allLegal[counter].final_rank = 2;
      			allLegal[counter].final_file = fileToIndice(initial->file) + 1;
      			counter++;
  				}
  			}
  			//en passant to bottom left
  			if((piece -> color == Black) && (initial -> rank == 4) && (*(chessboardP + (fileToIndice(initial->file) - 1) +(2*8)) == NULL))
  			{
  				if((opp_last_move -> pieceAtInitial == Pawn) && (opp_init_rank == 2) && (opp_final_rank == 4) && (initial -> file == (opp_final_file + 1)))
  				{
  					allLegal[counter].initial_rank = initial->rank - 1;
      			allLegal[counter].initial_file = fileToIndice(initial->file);
      			allLegal[counter].final_rank = 2;
      			allLegal[counter].final_file = fileToIndice(initial->file) - 1; 
      			counter++;
  				}
  			}
  		}//end of en passant
  		
  }
   else//every other piece
  {
    

    int upRank = 99;
    int downRank = -99;
    int rightFile = 99;
    int leftFile = -99;
    
    up.file = initial->file;
    down.file = initial->file;
    right.rank = initial->rank;
    left.rank = initial->rank;
    left.file = initial->file;
    right.file = initial->file;
    //column:
    for(int i = 0; i < 8; i++)//rank
    {
      if((*(chessboardP + fileToIndice(initial->file) + (i * 8))) != NULL)
      {
      //UP
        int temp = upRank;
        upRank = i - (initial->rank - 1);
        if(upRank > 0 && upRank < temp)
        {
          if((**(chessboardP + fileToIndice(initial->file) + (i * 8))).color == piece->color)//White
            {
              up.rank = i + 1 - 1;
              //up now holds last possible move in the northern direction for a white piece
            }
          else if((**(chessboardP + fileToIndice(initial->file) + (i * 8))).color == oppColor)//black
            {
              up.rank = i + 1;
              //up now holds last possible move in the northern direction for a black piece
            }
        }
        else
        {
          upRank = temp;
        }
        
        //DOWN
        if(initial->rank > 1)
          {
           int temp2 = downRank;
        downRank = i - (initial->rank - 1);
        if(downRank < 0 && downRank > temp2)
        {
          if((**(chessboardP + fileToIndice(initial->file) + (i * 8))).color == piece->color)//White
            {
              down.rank = i + 1 + 1;
              //down now holds last possible move in the southern direction if a white piece
            }
          else if((**(chessboardP + fileToIndice(initial->file) + (i * 8))).color == oppColor)//black
            {
              down.rank = i + 1;
              //down now holds last possible move in the southern direction if a black piece
            }
        }
        else
        {
          downRank = temp2;
        }
        }
        else
          {
            down.rank = -1;//ifdownRank = -99?
            down.file = 'N';
          }
      } 
    
      if((*(chessboardP + i + ((initial->rank - 1) * 8))) != NULL)
        {
        //RIGHT
        if(fileToIndice(initial->file) < 7)
        {
        int temp3 = rightFile;
        rightFile = i - fileToIndice(initial->file);
        if(rightFile > 0 && rightFile < temp3)
        {
          if((**(chessboardP + i + ((initial->rank - 1) * 8))).color == piece->color)//White
            {
              right.file = indiceToFile(i - 1);
              //right now holds last possible move in the eastern direction for a white piece
            }
          else if((**(chessboardP + i + ((initial->rank - 1) * 8))).color == oppColor)//black
            {
              right.file = indiceToFile(i);
              //right now holds last possible move in the eastern direction for a black piece
            }
        }
        else
        {
          rightFile = temp3;
        }
        }
        else
          {
              right.rank = -1;
              right.file = 'N';
          }
        
        //LEFT
        if(fileToIndice(initial->file) > 0)
          {
           int temp4 = leftFile;
        leftFile = i - fileToIndice(initial->file);
        if(leftFile < 0 && leftFile > temp4)
        {
          if((**(chessboardP + i + ((initial->rank - 1) * 8))).color == piece->color)//White
            {
              left.file = indiceToFile(i + 1);
              //down now holds last possible move in the southern direction if a white piece
            }
          else if((**(chessboardP + i + ((initial->rank - 1) * 8))).color == oppColor)//black
            {
              left.file = indiceToFile(i);
              //down now holds last possible move in the southern direction if a black piece
            }
        }
        else
        {
          leftFile = temp4;
        }
        }
        else
          {
            left.rank = -1;
            left.file = 'N';
          }
      
      }
   //  if((*(chessboardP + i + ((initial->rank - 1) * 8))) == NULL)
     // {
        if(rightFile == 99)
        {
          right.rank = initial->rank;
          right.file = 'h';
        }
        if(leftFile == -99)
        {
          left.rank = initial->rank;
          left.file = 'a';
        }
     // }
         if(upRank == 99)
        {
          up.rank = 8;
          up.file = initial->file;
        }
        if(downRank == -99)
        {
          down.rank = 1;
          down.file = initial->file;
        }
      
    }
    
    upLeft.file = 'N';
    upLeft.rank = -1;
    upRight.rank = -1;
    upRight.file = 'N';
    downLeft.file = 'N';
    downLeft.rank = -1;
    downRight.rank = -1;
    downRight.file = 'N';
    //Diagonals
    int j = initial->rank - 1;
    int k = fileToIndice(initial->file);
    if(fileToIndice(initial->file) < 7)
    {
    for(int i = (initial->rank - 1); i < 8; i++)//upRight
    {
      j++;
      k++;
      if(j < 8 && k < 8)
      {
      if((*(chessboardP + k + (j * 8))) != NULL)
      {
        if((**(chessboardP + k + (j * 8))).color == piece->color)//White
            {
              upRight.rank = j - 1 + 1;
              upRight.file = indiceToFile(k);
              break;
            }
          else if((**(chessboardP + k + (j * 8))).color == oppColor)//black
            {
              upRight.rank = j + 1;
              upRight.file = indiceToFile(k);
              break;
            }
      }
       else if((*(chessboardP + k + (j * 8))) == NULL)
      {
        if(j == 7 || k == 7)
        {
          upRight.rank = j + 1;
          upRight.file = indiceToFile(k);
        }
      }
      }
    }
    }
    else
    {
      upRight.rank = -1;
      upRight.file = 'N';
    }
    
    if(fileToIndice(initial->file) < 7)
    {
    j = initial->rank - 1;
    k = fileToIndice(initial->file);
    for(int i = (initial->rank - 1); i >= 0; i--)//downRight
    {
        j--;
        k++;
      if(j >= 0 && k < 8)
      {
      if((*(chessboardP + k + (j * 8))) != NULL)
      {
        if((**(chessboardP + k + (j * 8))).color == piece->color)//White
            {
              downRight.rank = j + 1 + 1;
              downRight.file = indiceToFile(k);
              break;
            }
          else if((**(chessboardP + k + (j * 8))).color == oppColor)//black
            {
              downRight.rank = j + 1;
              downRight.file = indiceToFile(k);
              break;
            }
      }
       else if((*(chessboardP + k + (j * 8))) == NULL)
      {
        if(j == 0 || k == 7)
        {
          downRight.rank = j + 1;
          downRight.file = indiceToFile(k);
        }
      }
      }
    }
    }
    else
    {
      downRight.rank = -1;
      downRight.file = 'N';
    }
    
    if(fileToIndice(initial->file) > 0)
    {
    j = initial->rank - 1;
    k = fileToIndice(initial->file);
    for(int i = (initial->rank - 1); i < 8; i++)//upLeft
    {
    j++;
    k--; 
    if(j < 8 && k >= 0)
      { 
      if((*(chessboardP + k + (j * 8))) != NULL)
      {
        if((**(chessboardP + k + (j * 8))).color == piece->color)//White
            {
              upLeft.rank = j - 1 + 1;
              upLeft.file = indiceToFile(k);
              break;
            }
          else if((**(chessboardP + k + (j * 8))).color == oppColor)//black
            {
              upLeft.rank = j + 1;
              upLeft.file = indiceToFile(k);
              break;
            }
      }
      else if((*(chessboardP + k + (j * 8))) == NULL)
      {
        if(j == 7 || k == 0)
        {
          upLeft.rank = j + 1;
          upLeft.file = indiceToFile(k);
        }
      }
      }
    }
    }
     else
    {
      upLeft.rank = -1;
      upLeft.file = 'N';
    }
    
    if(fileToIndice(initial->file) > 0)
    {
    j = initial->rank - 1;
    k = fileToIndice(initial->file);
    for(int i = (initial->rank - 1); i >= 0; i--)//downLeft
    {
     j--;
     k--;
    if(j >=0 && k >=0)
      {
      if((*(chessboardP + k + (j * 8))) != NULL)
      {
        if((**(chessboardP + k + (j * 8))).color == piece->color)//White
            {
              downLeft.rank = j + 1 + 1;
              downLeft.file = indiceToFile(k);
              break;
            }
          else if((**(chessboardP + k + (j * 8))).color == oppColor)//black
            {
              downLeft.rank = j + 1;
              downLeft.file = indiceToFile(k);
              break;
            }
      }
       else if((*(chessboardP + k + (j * 8))) == NULL)
      {
        if(j == 0 || k == 0)
        {
          downLeft.rank = j + 1;
          downLeft.file = indiceToFile(k);
        }
      }
      }
    }
    }
     else
    {
      downLeft.rank = -1;
      downLeft.file = 'N';
    }
    
    //printf("upLeft file %c, rank %d", upLeft.file, upLeft.rank);
 
  //adding elements to allLegal array
  counter = 0;
  for(int i = 0; i < 32; i++)
  {
    if(fileToIndice(allMoves[i].file) == fileToIndice(initial->file))
    {
    //up
      if(up.file != 'N')
      {
        if(allMoves[i].rank <= up.rank && allMoves[i].rank > initial->rank)
        {
          allLegal[counter].initial_rank = initial->rank - 1;
          allLegal[counter].initial_file = fileToIndice(initial->file);
          allLegal[counter].final_rank = allMoves[i].rank - 1;
          allLegal[counter].final_file = fileToIndice(allMoves[i].file);
          counter++;
        }
      }
    //down
      if(down.file != 'N')
      {
        if(allMoves[i].rank >= down.rank && allMoves[i].rank < initial->rank)
        {
          allLegal[counter].initial_rank = initial->rank - 1;
          allLegal[counter].initial_file = fileToIndice(initial->file);
          allLegal[counter].final_rank = allMoves[i].rank - 1;
          allLegal[counter].final_file = fileToIndice(allMoves[i].file);
          counter++;
        }
      }
    
    }
    
    if(allMoves[i].rank == initial->rank)
    {
      if(left.file != 'N')
      {
        if(fileToIndice(allMoves[i].file) >= fileToIndice(left.file) && fileToIndice(allMoves[i].file) < fileToIndice(initial->file))
        {
          allLegal[counter].initial_rank = initial->rank - 1;
          allLegal[counter].initial_file = fileToIndice(initial->file);
          allLegal[counter].final_rank = allMoves[i].rank - 1;
          allLegal[counter].final_file = fileToIndice(allMoves[i].file);
          counter++;
        }
      }
    
      if(right.file != 'N')
      {
        if(fileToIndice(allMoves[i].file) <= fileToIndice(right.file) && fileToIndice(allMoves[i].file) > fileToIndice(initial->file))
        {
          allLegal[counter].initial_rank = initial->rank - 1;
          allLegal[counter].initial_file = fileToIndice(initial->file);
          allLegal[counter].final_rank = allMoves[i].rank - 1;
          allLegal[counter].final_file = fileToIndice(allMoves[i].file);
          counter++;
        }
     } 
    }   
  
    if(allMoves[i].rank != initial->rank && fileToIndice(allMoves[i].file) != fileToIndice(initial->file))
    {
    if(upRight.file != 'N')
    {
      if(fileToIndice(allMoves[i].file) <= fileToIndice(upRight.file) && fileToIndice(allMoves[i].file) > fileToIndice(initial->file) && allMoves[i].rank <= upRight.rank && allMoves[i].rank > initial->rank)
      {
          allLegal[counter].initial_rank = initial->rank - 1;
          allLegal[counter].initial_file = fileToIndice(initial->file);
          allLegal[counter].final_rank = allMoves[i].rank - 1;
          allLegal[counter].final_file = fileToIndice(allMoves[i].file);
          counter++;
      }
    }
    
    if(upLeft.file != 'N')
    {
      if(fileToIndice(allMoves[i].file) >= fileToIndice(upLeft.file) && fileToIndice(allMoves[i].file) < fileToIndice(initial->file) && allMoves[i].rank <= upLeft.rank && allMoves[i].rank > initial->rank)
      {
 
          allLegal[counter].initial_rank = initial->rank - 1;
          allLegal[counter].initial_file = fileToIndice(initial->file);
          allLegal[counter].final_rank = allMoves[i].rank - 1;
          allLegal[counter].final_file = fileToIndice(allMoves[i].file);
          counter++;
      }
    }
    
    if(downRight.file != 'N')
    {
      if(fileToIndice(allMoves[i].file) <= fileToIndice(downRight.file) && fileToIndice(allMoves[i].file) > fileToIndice(initial->file) && allMoves[i].rank >= downRight.rank && allMoves[i].rank < initial->rank)
      {
          allLegal[counter].initial_rank = initial->rank - 1;
          allLegal[counter].initial_file = fileToIndice(initial->file);
          allLegal[counter].final_rank = allMoves[i].rank - 1;
          allLegal[counter].final_file = fileToIndice(allMoves[i].file);
          counter++;
      }
    }
    
    if(downLeft.file != 'N')
    {
      if(fileToIndice(allMoves[i].file) >= fileToIndice(downLeft.file) && fileToIndice(allMoves[i].file) < fileToIndice(initial->file) && allMoves[i].rank >= downLeft.rank && allMoves[i].rank < initial->rank)
      {
        allLegal[counter].initial_rank = initial->rank - 1;
          allLegal[counter].initial_file = fileToIndice(initial->file);
          allLegal[counter].final_rank = allMoves[i].rank - 1;
          allLegal[counter].final_file = fileToIndice(allMoves[i].file);
          counter++;
      }
    }
   }
   
  }
  
  
  }
  
    /*
    for(int i = 0; i < 32; i++)
  {
      if(allLegal[i].final_rank == -1)
      break;
      else
      printf("\nRank: %d File: %d \n", allLegal[i].final_rank, allLegal[i].final_file);
  }
  */
  
  //CASTLING
  if(piece -> pieceType == King)
	{
		if(piece -> hasMoved == 0)
		{
			if(piece -> color == White)
			{
				if(*(chessboardP+7+(0*8)) != NULL)
				{
					if(((**(chessboardP+7+(0*8))).pieceType == Rook) && ((**(chessboardP+7+(0*8))).hasMoved == 0) && 
						(*(chessboardP+5+(0*8)) == NULL) && (*(chessboardP+6+(0*8)) == NULL))
					{
						allLegal[counter].initial_rank = initial->rank - 1;
          	allLegal[counter].initial_file = fileToIndice(initial->file);
          	allLegal[counter].final_rank = initial->rank - 1;
          	allLegal[counter].final_file = 6;
          	counter++;
						
					}
				}
				if(*(chessboardP+0+(0*8)) != NULL)
				{
					if(((**(chessboardP+0+(0*8))).pieceType == Rook) && ((**(chessboardP+0+(0*8))).hasMoved == 0) && 
						(*(chessboardP+3+(0*8)) == NULL) && (*(chessboardP+2+(0*8)) == NULL) && (*(chessboardP+1+(0*8)) == NULL))
					{
						allLegal[counter].initial_rank = initial->rank - 1;
          	allLegal[counter].initial_file = fileToIndice(initial->file);
          	allLegal[counter].final_rank = initial->rank - 1;
          	allLegal[counter].final_file = 2;
          	counter++;
					}
				}

			}
			else if(piece -> color == Black)
			{
				if(*(chessboardP+7+(7*8)) != NULL)
				{
					if(((**(chessboardP+7+(7*8))).pieceType == Rook) && ((**(chessboardP+7+(7*8))).hasMoved == 0) && 
						(*(chessboardP+5+(7*8)) == NULL) && (*(chessboardP+6+(7*8)) == NULL))
					{
						allLegal[counter].initial_rank = initial->rank - 1;
          	allLegal[counter].initial_file = fileToIndice(initial->file);
          	allLegal[counter].final_rank = initial->rank - 1;
          	allLegal[counter].final_file = 6;
          	counter++;
					}
				}
				if(*(chessboardP+0+(7*8)) != NULL)
				{
					if(((**(chessboardP+0+(7*8))).pieceType == Rook) && ((**(chessboardP+0+(7*8))).hasMoved == 0) && 
						(*(chessboardP+3+(7*8)) == NULL) && (*(chessboardP+2+(7*8)) == NULL) && (*(chessboardP+1+(7*8)) == NULL))
					{	
						allLegal[counter].initial_rank = initial->rank - 1;
          	allLegal[counter].initial_file = fileToIndice(initial->file);
          	allLegal[counter].final_rank = initial->rank - 1;
          	allLegal[counter].final_file = 2;
          	counter++;
					}
				}
			}
		}
	}

	return allLegal;
 
} //allLegalMoves end







//returns 1 if legal, 0 if illegal
int isMoveLegal(t_chessPiece ** chessboardP, t_position* initial, t_position* final, t_logList *moveLog) //filters through all possible moves to see if the move is legal
{

    MOVESET *move = allLegalMoves(chessboardP, initial, moveLog);
    
    for(int i = 0; i < 32; i++)
      {
        if(move[i].final_rank != -1)
          {
            if(move[i].final_rank == (final->rank - 1) && move[i].final_file == fileToIndice(final->file))
            {
                return 1;
            }
           }
      }
      return 0;
}