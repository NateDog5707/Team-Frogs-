

#include <gtk/gtk.h>

#include <stdio.h>

#include "chessPieces.h"
#include "board.h"

#ifndef GUI_H
#define GUI_h

#define WINDOW_WIDTH  960
#define WINDOW_HEIGHT 540
#define SQUARE_SIZE 50
#define BOARD_WIDTH  (8*SQUARE_SIZE)
#define BOARD_HEIGHT (8*SQUARE_SIZE)

void gui_init_window(int argc, char*argv[]);

#endif
