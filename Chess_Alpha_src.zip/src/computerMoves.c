#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include <math.h>

#include "chessPieces.h"
#include "board.h"
#include "computerMoves.h"
#include "moveSet.h"
#include "checkStatus.h"

int boardValues[8][8] = {{0, 0, 0, 0, 0, 0, 0, 0},
		    								 {0, 0, 0, 0, 0, 0, 0, 0}, 
		    								 {1, 1, 2, 2, 2, 2, 1, 1},
									    	 {1, 1, 3, 4, 4, 3, 1, 1},
                         {1, 1, 3, 4, 4, 3, 1, 1},
                         {1, 1, 2, 2, 2, 2, 1, 1}, 
		    	               {0, 0, 0, 0, 0, 0, 0, 0},
		    	               {0, 0, 0, 0, 0, 0, 0, 0}};

//temp allLegalMoves
MOVESET *allLegalMovesComp(t_chessPiece **chessboardFirstP, int initial_file, int initial_rank)
{
	//MOVESET moveList[3];
	MOVESET *moveList = malloc(10 * sizeof(MOVESET));
			
	MOVESET m1 = {initial_file, initial_rank, 4, 5};
	MOVESET m2 = {initial_file, initial_rank, 4, 4};
	MOVESET m3 = {initial_file, initial_rank, 4, 3};
	MOVESET m4 = {initial_file, initial_rank, 5, 5};
	MOVESET m5 = {initial_file, initial_rank, 5, 4};
	MOVESET m6 = {initial_file, initial_rank, 5, 3};
	MOVESET m7 = {initial_file, initial_rank, 6, 5};
	MOVESET m8 = {initial_file, initial_rank, 6, 4};
	MOVESET m9 = {initial_file, initial_rank, 6, 3};
	MOVESET m10 = {initial_file, initial_rank, 7, 5};
	
	moveList[0] = m1;
	moveList[1] = m2;
	moveList[2] = m3;
	moveList[3] = m4;
	moveList[4] = m5;
	moveList[5] = m6;
	moveList[6] = m7;
	moveList[7] = m8;
	moveList[8] = m9;
	moveList[9] = m10;
	
	return moveList;
}


void ComputerMoves(t_chessPiece **chessboardFirstP, t_position *initial, t_position *final, char *computerColor, int difficulty, t_logList *moveLog)
{
	MOVESET *best_move = BestMove(chessboardFirstP, computerColor, difficulty, moveLog);
	
	//no more local vars, now passed in from main. this function does only converting now
	
	initial->rank = best_move->initial_rank +1;
	final->rank = best_move->final_rank +1;	
	

	switch (best_move -> initial_file){
		case 0:
			initial->file = 'a';
			break;
		case 1:
			initial->file = 'b';
			break;
		case 2:
			initial->file = 'c';
			break;
		case 3:
			initial->file = 'd';
			break;
		case 4:
			initial->file = 'e';
			break;
		case 5:
			initial->file = 'f';
			break;
		case 6:
			initial->file = 'g';
			break;
		case 7:
			initial->file = 'h';
			break;
		default:
			initial->file = 0;
			break;
	
	}
	
	
	switch (best_move -> final_file){
		case 0:
			final->file = 'a';
			break;
		case 1:
			final->file = 'b';
			break;
		case 2:
			final->file = 'c';
			break;
		case 3:
			final->file = 'd';
			break;
		case 4:
			final->file = 'e';
			break;
		case 5:
			final->file = 'f';
			break;
		case 6:
			final->file = 'g';
			break;
		case 7:
			final->file = 'h';
			break;
		default:
			final->file = 0;
			break;
	}
	
	
	//debug
//	printf("best move intial file: %c\n", initial->file);
//	printf("best move final file: %c\n", final->file);
//	
//	initial_rank = (best_move -> initial_rank) + 1;
//	final_rank = (best_move -> final_rank) + 1;
	
	//debug
//	printf("ima do something bad\n");
//	printf("intial position: %c %d\n", initial->file, initial->rank);
//	printf("final file: %c %d\n", final->file, final->rank);
 
/* ========MOVED TO MAIN=======
	//--------log stuff
	enum t_pieceType pieceAtInit = (*getPiece(chessboardFirstP, initial)).pieceType;
	enum t_pieceType pieceAtFin;
	if (getPiece(chessboardFirstP, final) != NULL){
		pieceAtFin = (*getPiece(chessboardFirstP, final)).pieceType;
	}
	else{
		pieceAtFin = None;
	}

	AppendMove(moveLog, initial, final, pieceAtInit, pieceAtFin);  //log.c
		
	//----- end log stuff
	
	
	move(chessboardFirstP, initial, final);
	*/
	
	
	
}

MOVELIST *CreateMoveList(void)
{
	MOVELIST *l;
 	l = (MOVELIST *)malloc(sizeof(MOVELIST));
	if(!l)
 	{
 		return NULL;
 	}
  l -> length = 0;
  l -> first = NULL;
  l -> last = NULL;
  return l;
}

void DeleteMoveList(MOVELIST *LIST)
{
	assert(LIST);
   
 	MOVEENTRY *current;
  current = LIST -> first;
   
  MOVEENTRY *NEXT = NULL;
   
  while(current)
  {
  	NEXT = current -> next;
  	DeleteMoveEntry(current);
   	//free(current);
     
    current = NEXT;
 	}
   
  LIST -> length = 0;
  LIST -> first = NULL;
  LIST -> last = NULL;
   
  free(LIST);

}

void AppendMoveEntry(MOVELIST *LIST, MOVESET *Moveset)
{
	assert(LIST);
 	assert(Moveset);
 	MOVEENTRY *entry = NULL;
  entry = (MOVEENTRY *)malloc(sizeof(MOVEENTRY));
   
  assert(entry);

	entry -> list = LIST;
 	entry -> next = NULL;
  entry -> moveset = Moveset;
  entry -> movevalue = 0;
   
  if(LIST -> last != NULL)
  {
  	LIST -> last -> next = entry;
   	entry -> prev = LIST -> last;
   	LIST -> last = entry;
 	}
  else
  {
  	entry -> prev = NULL;
   	LIST -> first = entry;
   	LIST -> last = entry;
 	}
  LIST -> length++;
}

void DeleteMoveEntry(MOVEENTRY *Moveentry)
{
	assert(Moveentry);
	
	Moveentry -> list = NULL;
	Moveentry -> prev = NULL;
	Moveentry -> next = NULL;
	Moveentry -> moveset = NULL;
	
	free(Moveentry);
	Moveentry = NULL;
	
}

void AssignMoveValues(t_chessPiece **chessboardFirstP, MOVELIST *LIST, int compcolor, int playercolor, t_logList *moveLog)
{	
	assert(LIST);
	
	//t_chessPiece* move_piece = NULL;
	t_chessPiece* captured_piece = NULL;
   
  MOVEENTRY *current;
  current = LIST -> first;
   
  MOVEENTRY *NEXT = NULL;
  
  //checks if the computer player is in check
	int is_incheck = 0;
	is_incheck = inCheck(playercolor, compcolor, chessboardFirstP, moveLog);
//	printf("hi from computer moves: incheck is %d\n", is_incheck);
	
	//creating new temp board to check
	t_chessPiece *tempchessBoard[8][8];
		
	int i, j;
	for(i = 0; i < 8; i++)
	{
		for(j = 0; j < 8; j++)
		{
			tempchessBoard[i][j] = *(chessboardFirstP + j + (i * 8)); 
		}
	}
		
	t_chessPiece **tempchessboardFirstP = &tempchessBoard[0][0];
	
  while(current)
  {
  	NEXT = current -> next; 
  	
  	//adding board value (boardValues[8][8] could change values if needed)
  	int i_rank = current -> moveset -> initial_rank;
  	int i_file = current -> moveset -> initial_file;
		int f_rank = current -> moveset -> final_rank;
  	int f_file = current -> moveset -> final_file;
  	t_position i;
		t_position f;
		i.rank = i_rank + 1;
		i.file = indiceToFile(i_file);
		f.rank = f_rank + 1;
		f.file = indiceToFile(f_file);
  	
  	current -> movevalue += boardValues[f_file][f_rank];
  	
  	//adding if could capture a piece (50 points, could be more or less, could be different for each piece)
  	/*if(&chessboardFirstP[file][rank] != NULL)
  	{
  		current -> movevalue += 50;
  	}*/
  	
	  
	  //move_piece = *(chessboardFirstP + i_file + (i_rank * 8));
  	captured_piece = *(chessboardFirstP + f_file + (f_rank * 8));
  	
  	
  	if(captured_piece != NULL)
  	{
  		switch(captured_piece -> pieceType){
  			case Pawn:
					current -> movevalue += 10;
					break;
				case Rook:
					current -> movevalue += 50;
					break;
				case Knight:
					current -> movevalue += 30;
					break;
				case Bishop:
					current -> movevalue += 30;
					break;
				case Queen:
					current -> movevalue += 100;
					break;
				case King:
					current -> movevalue += 200;
					break;
				case None:
					current -> movevalue += 0;
					break;
  		}
  	}
  	
  	
		//1. if it's in check
		//2. create temp board
		//3. try different moves to see if can get out of check (there should be one since checkmate is not true)
		//4. add a bunch of values to that move
		//5. subtract a bunch of values to moves that will put king in check again

		//adding more value to moving king is king is in check
  	if(is_incheck != 0) //in danger
		{
//			printf("hi from computer moves: king is in check\n");
			//current -> movevalue += 150;
//			printf("i_rank %d, i_file %c, f_rank %d, f_file %c\n", i.rank, i.file, f.rank, f.file); 
			move(tempchessboardFirstP, &i, &f);
//			printf("seg fault here\n");
			int is_check_again = 1;
			is_check_again = inCheck(playercolor, compcolor, tempchessboardFirstP, moveLog);
//			printf("is_check_again %d\n", is_check_again);
//			printf("seg fault here 2.0\n");
			if(is_check_again - is_incheck == 0) //not in danger anymore
			{
				//add lots of values to get king out of check
				current -> movevalue += 700;
			}
			else //still in danger
			{
				//subtract lots of values so that computer won't put king in check again
				current -> movevalue -= 700;
			
			}
			
			move(tempchessboardFirstP, &f, &i);
			

		}
		/*
		else
		{
			move(tempchessboardFirstP, &i, &f);
			
			
			//checks if after moving the piece will get threatened
			
			int k, l, m;
			for(k = 0; k < 8; k++)
			{
				for(l = 0 ; l < 8; l++)
				{
					t_chessPiece* tempboard_piece = *(tempchessboardFirstP + k + (l * 8));
					printf("seg here? %d\n", l);
			
					if(tempboard_piece != NULL && tempboard_piece -> color== playercolor)
					{
						printf("seg here maybe? %d\n", l);
						t_position tempboard_initial_position;
						tempboard_initial_position.rank = l + 1;
						tempboard_initial_position.file = indiceToFile(k);
				
						MOVESET *tempboardMovesArr;
						tempboardMovesArr = allLegalMoves(tempchessboardFirstP, &tempboard_initial_position, moveLog);
						m = 0;
				
						while(tempboardMovesArr[m].final_rank != -1)
						{
							if((*(tempchessboardFirstP + tempboardMovesArr[m].final_file + (tempboardMovesArr[m].final_rank * 8))) -> color == compcolor)
							{
								current -> movevalue -= 100;
							}
						}
					}
				}
			}
			
			move(tempchessboardFirstP, &f, &i);
			
		
		}
		*/
		
  	
  	//subtracting if could be captured (loop through enemy legal moves to check) 
  	//create new chessboard with this move to check
  	//t_chessPiece *tempBoard?
  	/*int i, j;
  	for(i = 0; i < 8; i++)
  	{
  		for(j = 0; j < 8; j++)
  		{
  			allLegalMovesComp(chessBoard, i, j);
  		}
  	}*/

    current = NEXT;
  }

}

MOVESET *BestMove(t_chessPiece **chessboardFirstP, char *computerColor, int difficulty, t_logList *moveLog)
{	
	//get computer color
	int compcolor;
	int playercolor;
	//printf("color: %s\n", computerColor);
	
	if(strcmp(computerColor, "White") == 0)
	{
		compcolor = 1;
		playercolor = 0;
	}
	else
	{
		compcolor = 0;
		playercolor = 1;
	}
	

	//initialize movelist
	MOVELIST *moves = CreateMoveList();
	
	int i, j, k;
	for(i = 0; i < 8; i++)
	{
		for(j = 0 ; j < 8; j++)
		{
			t_chessPiece* piece = *(chessboardFirstP + i + (j * 8));
			
			if(piece != NULL && piece->color == compcolor)
			{
				t_position temp_initial_position;
				temp_initial_position.rank = j + 1;
				temp_initial_position.file = indiceToFile(i);
				
				//debug
//				printf("piece: %c %d\n", temp_initial_position.file, temp_initial_position.rank);

				MOVESET *tempMovesArr;
				tempMovesArr = allLegalMoves(chessboardFirstP, &temp_initial_position, moveLog);
				k = 0;
				
				while(tempMovesArr[k].final_rank != -1)
				{
					//debug
//					printf("initial_position: %d, %d, final_ position: %d, %d\n", tempMovesArr[k].initial_file, tempMovesArr[k].initial_rank, tempMovesArr[k].final_file, tempMovesArr[k].final_rank);
					
					AppendMoveEntry(moves, &tempMovesArr[k]);
					k++;
				}
			}
		}
	}
	
	AssignMoveValues(chessboardFirstP, moves, compcolor, playercolor, moveLog);
	
	MOVESET *m = NULL;
	
	if(difficulty == 0)
	{
		//return random one (this could be easy mode)
		
		srand(time(NULL));
		int random_move = (rand() % (moves -> length));
		int count = 0;
	
		MOVEENTRY *CURRENT = NULL;
		MOVEENTRY *NEXT = NULL;
		CURRENT = moves -> first;
	
		while(CURRENT)
		{	
			NEXT = CURRENT -> next;
		
			if(count == random_move)
			{
				m = CURRENT -> moveset;
			}
		
			count++;
			CURRENT = NEXT;
		}
		
	}
	else if(difficulty == 1)
	{
		//return max movevalue one (this could be normal mode)
	
		MOVEENTRY *CURRENT = NULL;
		MOVEENTRY *NEXT = NULL;
		CURRENT = moves -> first;
	
		int max_value = 0;
	
		while(CURRENT)
		{	
			NEXT = CURRENT -> next;
		
			if(CURRENT -> movevalue > max_value)
			{
				m = CURRENT -> moveset;
				max_value = CURRENT -> movevalue;
			}
		
			CURRENT = NEXT;
		}
		
	}
	
	DeleteMoveList(moves);
	return m;
	
}



			
