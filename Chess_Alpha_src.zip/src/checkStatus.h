#include "chessPieces.h"
#include "moveSet.h"
#include "log.h"





#ifndef CHECKSTATUS_H
#define CHECKSTATUS_H


t_position findEnemyKing(int oppColor, t_chessPiece** chessBoard); 

int inCheck(int moverColor, int oppColor, t_chessPiece** chessBoard, t_logList *moveLog);

    /*
        1. Color of King we are checking 
	2. Find King
	  if(chessPiece->color == Black && chesspiece.pieceType = King)
	  store rank and file in a variable
	3. Find surrounding pieces
	  look all directions
	  call allLegalMoves for pieces 
	  for diagonal, if not a bishop or queen or pawn, do not check moves.
	  for cardinal directions, if a bishop, or pawn, do not check moves.
	  for pieces 2 spaces away from king, check if it is a knight.
	4. calculate moves for pieces
	5. return 0 if king not in danger, 1 if king is in danger
  
     */
     
int charToInt(char file);
char intToChar(int file);     
     
     
int inCheckmate(int oppColor, t_chessPiece ** chessboard, t_logList *moveLog);
int isKingInCheck(t_chessPiece *chessboard, char playerColor);
void inStalemate(t_chessPiece * chessboard);



#endif


