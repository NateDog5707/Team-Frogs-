Author: 
Team Frogs
Christopher Wan, Yian Lin, Tyler Chew, Nathan Yan, Katherine Hsu

Version: 
Chess Alpha Version

Date: 
04/24/2023

General Instructions:
To install, follow the instructions in INSTALL.TXT
1. Download Chess_Alpha_src.tar.gz
2. Use command "tar -xvzf Chess_Alpha_src.tar.gz"
3. Use command "cd Chess_Alpha_src.tar.gz"
4. Use command "make"

To play the chess game
1. Use command "./chess"
2. Enter a menu option
   1. Start Game
   2. Log File
   3. Rules of Chess
   4. Exit Program


For more detailed instructions, refer to Chess_UserManual.pdf